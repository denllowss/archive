import makeWASocket, { DisconnectReason, WAMessageStubType, fetchLatestBaileysVersion, makeInMemoryStore, useMultiFileAuthState, jidNormalizedUser, downloadMediaMessage, prepareWAMessageMedia, generateForwardMessageContent, generateWAMessageFromContent } from 'baileys'
import fs from 'node:fs/promises'
import fssync from 'node:fs'
import path from 'node:path'
import pino from 'pino'
import chalk from 'chalk'
import sharp from 'sharp'
import WebP from 'node-webpmux'
import { fileURLToPath, pathToFileURL } from 'node:url'
import './error.js'
import './lib/config.js'
import './lib/functions.js'
import './lib/economy.js'
import handler from './handler.js'
import system from './lib/adapter.js'
import { models } from './lib/models.js'
import { Config, Utils } from './lib/core.js'

const root = path.dirname(fileURLToPath(import.meta.url))
const store = makeInMemoryStore({ logger: pino({ level: 'silent' }) })
const deletedMessageCache = new Map()
const cacheKey = key => `${key?.remoteJid || ''}|${key?.id || ''}`
const rememberMessage = message => {
  const key = cacheKey(message?.key)
  if (!key || key === '|') return
  message._antiDeleteText = textOf(message?.message)
  deletedMessageCache.set(key, message)
  if (deletedMessageCache.size > 2000) deletedMessageCache.delete(deletedMessageCache.keys().next().value)
}

async function listPluginFiles(directory) {
  const files = []
  async function walk(dir) {
    const entries = await fs.readdir(dir, { withFileTypes: true })
    const subwalks = []
    for (const item of entries) {
      const fullPath = path.join(dir, item.name)
      if (item.isDirectory()) subwalks.push(walk(fullPath))
      else if (item.isFile() && item.name.endsWith('.js')) files.push(fullPath)
    }
    if (subwalks.length) await Promise.all(subwalks)
  }
  await walk(directory)
  return files
}

function createPluginManager(directory, registry) {
  const watchers = new Map()
  let timer = null
  const label = file => path.relative(root, file).replaceAll('\\', '/')
  const logError = (file, error) => console.error(`\n[PLUGIN ERROR] ${label(file)}\n${error?.stack || error}\n[PLUGIN] Plugin dilewati; bot tetap berjalan.\n`)

  async function reload() {
    let files
    try { files = await listPluginFiles(directory) }
    catch (error) { console.error('[PLUGIN ERROR] Tidak dapat membaca folder plugins:', error); return }
    const current = new Set(files)
    for (const file of Object.keys(registry)) if (!current.has(file)) {
      delete registry[file]
      console.log(`[PLUGIN REMOVE] ${label(file)}`)
    }
    await Promise.all(files.map(async file => {
      try {
        const module = await import(`${pathToFileURL(file).href}?update=${Date.now()}`)
        if (!module.run || typeof module.run !== 'object') {
          if (registry[file]) delete registry[file]
          console.warn(`[PLUGIN SKIP] ${label(file)} — export 'run' tidak ditemukan.`)
          return
        }
        const existed = Boolean(registry[file])
        registry[file] = module
        console.log(existed ? `[PLUGIN RELOAD] ${label(file)}` : `[PLUGIN LOAD] ${label(file)}`)
      } catch (error) {
        logError(file, error)
      }
    }))
    watchDirectories(files)
  }

  function scheduleReload() {
    clearTimeout(timer)
    timer = setTimeout(() => reload().catch(error => console.error('[PLUGIN ERROR] Reload gagal:', error)), 350)
  }
  function watchDirectories(files) {
    const directories = new Set([directory, ...files.map(file => path.dirname(file))])
    for (const dir of directories) if (!watchers.has(dir)) {
      try {
        const watcher = fssync.watch(dir, { persistent: true }, (_event, name) => {
          if (!name || name.toString().endsWith('.js')) scheduleReload()
        })
        watcher.on('error', error => console.error(`[PLUGIN WATCH ERROR] ${dir}:`, error.message))
        watchers.set(dir, watcher)
      } catch (error) { console.error(`[PLUGIN WATCH ERROR] ${dir}:`, error.message) }
    }
  }
  return { start: reload, registry }
}

const PREFERRED_MESSAGE_TYPES = [
  'conversation', 'extendedTextMessage', 'imageMessage', 'videoMessage',
  'documentMessage', 'stickerMessage', 'audioMessage', 'buttonsResponseMessage', 'listResponseMessage',
  'templateButtonReplyMessage', 'interactiveResponseMessage',
  'ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension'
]
const WRAPPER_MESSAGE_TYPES = new Set(['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension'])

function unwrap(message = {}) {
  let type, value
  for (const name of PREFERRED_MESSAGE_TYPES) {
    const candidate = message[name]
    if (candidate != null) { type = name; value = candidate; break }
  }
  if (type === undefined) {
    for (const key in message) {
      const candidate = message[key]
      if (candidate != null) { type = key; value = candidate; break }
    }
  }
  if (WRAPPER_MESSAGE_TYPES.has(type) && value?.message) return unwrap(value.message)
  return { type, value }
}
function textOf(message) {
  const { type, value } = unwrap(message)
  if (typeof value === 'string') return value
  if (type === 'interactiveResponseMessage') {
    try {
      const params = JSON.parse(value?.nativeFlowResponseMessage?.paramsJson || '{}')
      return params.id || params.selectedId || params.rowId || ''
    } catch { return '' }
  }
  return value?.text || value?.caption || value?.conversation || value?.selectedButtonId || value?.selectedId || value?.singleSelectReply?.selectedRowId || value?.singleSelectReply?.selectedRowId || ''
}

async function addStickerExif(webp, packname, author) {
  const image = new WebP.Image()
  await image.load(webp)
  const stickerMetadata = {
    'sticker-pack-id': 'com.whatsapp.stickerpack',
    'sticker-pack-name': String(packname || 'Sticker by'),
    'sticker-pack-publisher': String(author || '© neoxr.js'),
    emojis: ['']
  }
  const json = Buffer.from(JSON.stringify(stickerMetadata), 'utf8')
  const exif = Buffer.from([
    0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00,
    0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00,
    0x00, 0x00
  ])
  image.exif = Buffer.concat([exif, json])
  image.exif.writeUIntLE(json.length, 14, 4)
  return image.save(null)
}
function makeMessage(raw, sock) {
  const { key, message = {}, pushName = '' } = raw
  const { type, value } = unwrap(message)
  const chat = key.remoteJid || key.remoteJidAlt || ''
  const senderId = key.participantAlt || key.participant || key.remoteJidAlt || chat
  const quotedSender = value?.contextInfo?.participantAlt || value?.contextInfo?.participant || chat
  const sender = jidNormalizedUser(senderId)
  const quotedMessage = value?.contextInfo?.quotedMessage
  const quotedInfo = quotedMessage ? unwrap(quotedMessage) : null
  const quoted = quotedMessage ? {
    sender: jidNormalizedUser(quotedSender),
    ...quotedInfo.value,
    key: { remoteJid: chat, id: value.contextInfo.stanzaId, participant: quotedSender, fromMe: quotedSender === sock.user?.id },
    message: quotedMessage,
    msg: quotedInfo.value,
    mtype: quotedInfo.type,
    text: textOf(quotedMessage),
    mimetype: quotedInfo.value?.mimetype || ''
  } : null
  if (quoted) quoted.download = () => sock.downloadMediaMessage({ key: quoted.key, message: quoted.message })
  const m = { ...raw, key, chat, sender, pushName, message, mtype: type, msg: value, body: textOf(message), isGroup: chat?.endsWith('@g.us'), fromMe: key.fromMe, mentionedJid: value?.contextInfo?.mentionedJid || [], quoted }
  m.reply = (text, options = {}) => sock.sendMessage(chat, { text: String(text), ...options }, { quoted: raw })
  m.download = () => downloadMediaMessage(raw, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage })
  return m
}

async function resolveMessageLids(sock, m) {
  const resolve = async jid => {
    if (!jid || !String(jid).endsWith('@lid')) return jid
    try {
      const ids = await Promise.race([
        sock.findUserId(jid),
        Utils.delay(2500).then(() => { throw new Error('LID lookup timeout') })
      ])
      return ids?.phoneNumber || jid
    } catch (error) {
      console.warn(`[LID] Tidak dapat mengubah ${jid} ke nomor: ${error?.message || error}`)
      return jid
    }
  }
  const [sender, quotedSender, mentionedJid] = await Promise.all([
    resolve(m.sender),
    m.quoted?.sender ? resolve(m.quoted.sender) : Promise.resolve(m.quoted?.sender),
    Array.isArray(m.mentionedJid) && m.mentionedJid.length ? Promise.all(m.mentionedJid.map(resolve)) : Promise.resolve(m.mentionedJid || [])
  ])
  const originalSender = m.sender
  m.sender = sender
  if (originalSender !== m.sender) m.lid = originalSender
  if (m.quoted?.sender) {
    const originalQuotedSender = m.quoted.sender
    m.quoted.sender = quotedSender
    if (originalQuotedSender !== m.quoted.sender) m.quoted.lid = originalQuotedSender
  }
  m.mentionedJid = mentionedJid
  return m
}

const logTimeFormatter = new Intl.DateTimeFormat('id-ID', { timeZone: Config.timezone, hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
function logMessage(raw, m, body, prefix, command, words) {
  const time = logTimeFormatter.format(new Date())
  const sender = String(m.sender || '-').replace(/@.+/, '')
  const id = raw.key?.id || '-'
  const content = body || `[${m.mtype || 'message'}]`
  if (prefix && command) {
    console.log(chalk.gray(time), chalk.yellow.bold('[CMD]'), chalk.green(sender), chalk.gray(id), chalk.white(`${prefix}${command}${words?.length ? ` ${words.join(' ')}` : ''}`))
  } else {
    console.log(chalk.gray(time), chalk.cyan.bold('[MSG]'), chalk.green(sender), chalk.gray(id), chalk.white(content))
  }
}

const MENTION_TAG_REGEX = /@(\d{5,})/g

function decorate(sock) {
  const nativeFetchBlocklist = typeof sock.fetchBlocklist === 'function'
    ? sock.fetchBlocklist.bind(sock)
    : null
  const nativeSendMessage = sock.sendMessage.bind(sock)
  sock.sendMessage = async (jid, content, options = {}) => {
    try {
      const result = await nativeSendMessage(jid, content, options)
      console.log(`[SEND OK] target=${jid} | type=${Object.keys(content || {}).filter(key => key !== 'text').join(',') || 'text'} | id=${result?.key?.id || '-'}`)
      return result
    } catch (error) {
      console.error(`[SEND ERROR] target=${jid} | ${error?.stack || error}`)
      throw error
    }
  }
  const mentionIndex = new Map()
  const mentionsIn = (text, explicit = []) => {
    const detected = String(text || '').match(MENTION_TAG_REGEX) || []
    const mentions = detected.map(tag => {
      const number = tag.slice(1)
      return mentionIndex.get(number) || `${number}@s.whatsapp.net`
    })
    return [...new Set([...mentions, ...(explicit || [])])]
  }
  sock.reply = (jid, text, quoted, options = {}) => {
    const mentions = mentionsIn(text, options.mentions)
    return sock.sendMessage(jid, { text: String(text), ...options, ...(mentions.length ? { mentions } : {}) }, quoted ? { quoted } : {})
  }
  sock.downloadMediaMessage = async media => {
    let message = media
    if (!media?.message) {
      const mime = String(media?.mimetype || '')
      const type = /video/.test(mime) ? 'videoMessage'
        : /audio/.test(mime) ? 'audioMessage'
          : /sticker/.test(mime) ? 'stickerMessage'
            : /document/.test(mime) ? 'documentMessage' : 'imageMessage'
      message = { key: {}, message: { [type]: media } }
    }
    return downloadMediaMessage(message, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage, logger: pino({ level: 'silent' }) })
  }
  sock.sendReact = (jid, text, key) => sock.sendMessage(jid, { react: { text, key } })
  sock.sendFile = async (jid, data, filename = 'file', caption = '', quoted = null, mediaOptions = {}, properties = {}) => {
    const buffer = Buffer.isBuffer(data) ? data : await (Utils.isUrl(data) ? Utils.fetchAsBuffer(data) : fs.readFile(data))
    const extension = path.extname(filename || (typeof data === 'string' ? data : '')).toLowerCase()
    const header = buffer.subarray(0, 16)
    const isWebp = header.subarray(0, 4).toString() === 'RIFF' && header.subarray(8, 12).toString() === 'WEBP'
    const isImage = /\.(jpe?g|png|webp)$/i.test(extension) || header[0] === 0xff && header[1] === 0xd8 || header.subarray(0, 8).toString('hex') === '89504e470d0a1a0a' || isWebp
    const isVideo = /\.(mp4|mkv|webm|mov)$/i.test(extension) || header.subarray(4, 8).toString() === 'ftyp'
    const isAudio = /\.(mp3|ogg|m4a|wav|aac)$/i.test(extension) || header.subarray(0, 4).toString() === 'OggS' || header.subarray(0, 3).toString() === 'ID3' || header.subarray(0, 4).toString() === 'RIFF'
    const detectedType = isImage ? 'image' : isVideo ? 'video' : isAudio ? 'audio' : 'document'
    const type = mediaOptions.document ? 'document' : mediaOptions.audio ? 'audio' : detectedType
    const contextInfo = { ...(properties.contextInfo || {}), ...(mediaOptions.contextInfo || {}) }
    const thumbnail = properties.jpegThumbnail || mediaOptions.jpegThumbnail || mediaOptions.APIC
    const content = {
      [type]: buffer,
      ...(caption && type !== 'audio' ? { caption } : {}),
      ...(type === 'document' ? { fileName: filename || 'file', mimetype: mediaOptions.mimetype || 'application/octet-stream' } : {}),
      ...(type === 'audio' ? { mimetype: mediaOptions.mimetype || 'audio/mpeg', ptt: Boolean(mediaOptions.ptt) } : {}),
      ...(thumbnail ? { jpegThumbnail: thumbnail } : {}),
      ...(Object.keys(contextInfo).length ? { contextInfo } : {}),
      ...(properties.viewOnce ? { viewOnce: true } : {}),
      ...Object.fromEntries(Object.entries(mediaOptions).filter(([key]) => !['contextInfo', 'mimetype', 'ptt', 'document', 'audio', 'APIC', 'jpegThumbnail'].includes(key)))
    }
    return sock.sendMessage(jid, content, quoted ? { quoted } : {})
  }
  sock.sendSticker = async (jid, data, quoted, options = {}) => {
    const source = Buffer.isBuffer(data) ? data : await (Utils.isUrl(data) ? Utils.fetchAsBuffer(data) : fs.readFile(data))
    let sticker = source
    if (!(source.subarray(0, 4).toString() === 'RIFF' && source.subarray(8, 12).toString() === 'WEBP')) {
      try { sticker = await sharp(source).webp({ quality: 82 }).toBuffer() }
      catch (error) { console.warn(`[STICKER] Konversi WebP gagal, mengirim buffer asli: ${error.message}`) }
    }
    if (options.meta || options.packname || options.author) {
      try {
        const fallback = global.db?.setting || {}
        const tagged = await addStickerExif(sticker, options.packname || fallback.sk_pack, options.author || fallback.sk_author)
        await sharp(tagged).metadata()
        sticker = tagged
      } catch (error) {
        console.warn(`[STICKER EXIF] Metadata gagal dipasang: ${error.message}`)
      }
    }
    const contextInfo = options.contextInfo || (options.mentions?.length ? { mentionedJid: options.mentions } : undefined)
    return sock.sendMessage(jid, { sticker, ...(contextInfo ? { contextInfo } : {}) }, quoted ? { quoted } : {})
  }
  sock.sendAlbumMessage = async (jid, files = [], quoted) => {
    for (const file of files) await sock.sendFile(jid, file.url || file.buffer || file, file.filename || 'file', file.caption || '', quoted)
  }
  sock.sendContact = (jid, contacts = [], quoted) => sock.sendMessage(jid, { contacts: { displayName: 'Contacts', contacts: contacts.map(contact => ({ vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${contact.name || contact.fullName || contact.number}\nTEL;type=CELL;type=VOICE;waid=${String(contact.number || '').replace(/\D/g, '')}:${contact.number || ''}\nEND:VCARD` })) } }, quoted ? { quoted } : {})
  sock.replyButton = (jid, buttons = [], quoted, options = {}) => sock.sendMessage(jid, { text: [options.text || options.caption || '', ...buttons.map((button, index) => `${index + 1}. ${button.text || button.displayText || button.id || 'Button'}`)].filter(Boolean).join('\n') }, quoted ? { quoted } : {})
  sock.sendIAMessage = (jid, buttons = [], quoted, options = {}, context = {}) => {
    const text = [options.header || '', options.content || options.text || options.caption || '', options.footer || ''].filter(Boolean).join('\n\n')
    const mentionedJid = context.mentionedJid || context.mentions || []
    return sock.sendMessage(jid, { text: text || buttons.map(button => button.name || 'Button').join('\n'), ...(mentionedJid.length ? { mentions: mentionedJid } : {}) }, quoted ? { quoted } : {})
  }
  sock.sendCarousel = (jid, cards = [], quoted) => sock.sendMessage(jid, { text: cards.map((card, index) => `${index + 1}. ${card.title || card.body || card.text || ''}`).join('\n') || 'No content.' }, quoted ? { quoted } : {})
  sock.sendFromAI = (jid, text, quoted) => sock.reply(jid, text, quoted)
  sock.sendMetaMsg = (jid, messages = [], quoted) => Promise.all(messages.map(message => sock.sendMessage(jid, message, quoted ? { quoted } : {})))
  sock.pollResult = (jid, poll, quoted) => sock.sendMessage(jid, { poll: { name: poll.name || poll.question || 'Poll', values: poll.values || poll.options || [], selectableCount: poll.selectableCount || 1 } }, quoted ? { quoted } : {})
  sock.saveMediaMessage = async message => { const buffer = await downloadMediaMessage(message, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage }); const file = path.join(root, 'temp', `media-${Date.now()}`); await fs.mkdir(path.dirname(file), { recursive: true }); await fs.writeFile(file, buffer); return file }
  sock.groupStatus = (jid, options = {}) => sock.groupSettingUpdate(jid, options.announcement ? 'announcement' : 'not_announcement')
  sock.sendThumbnail = async (imageInput, text, options = {}) => {
    if (!imageInput) throw new Error('[sendThumbnail] thumbnail tidak boleh kosong.')
    const jid = options.jid || options.chat
    if (!jid) throw new Error('[sendThumbnail] jid tujuan tidak ada.')
    const url = options.url || Utils.generateLink(String(text))[0] || global.db?.setting?.link || 'https://www.youtube.com'
    const loadImage = async input => {
      if (Buffer.isBuffer(input)) return input
      if (Utils.isUrl(input)) return Utils.fetchAsBuffer(input)
      if (typeof input === 'string' && /^[A-Za-z0-9+/=]+$/.test(input) && input.length > 100) return Buffer.from(input, 'base64')
      return fs.readFile(input)
    }
    const image = await loadImage(imageInput)
    const imageInfo = await sharp(image).metadata()
    const longestSide = Math.max(imageInfo.width || 0, imageInfo.height || 0)
    const thumbnailImage = longestSide > 1024
      ? sharp(image).resize({ width: 1024, height: 1024, fit: 'inside', withoutEnlargement: true })
      : sharp(image)
    const jpegThumbnail = await thumbnailImage.jpeg({ quality: 85 }).toBuffer()
    const finalInfo = await sharp(jpegThumbnail).metadata()
    let highQualityThumbnail
    try {
      const prepared = await prepareWAMessageMedia(
        { image: jpegThumbnail },
        { upload: sock.waUploadToServer, mediaTypeOverride: 'thumbnail-link' }
      )
      const media = prepared.imageMessage
      highQualityThumbnail = {
        directPath: media.directPath,
        mediaKey: media.mediaKey,
        mediaKeyTimestamp: media.mediaKeyTimestamp,
        width: finalInfo.width,
        height: finalInfo.height,
        fileSha256: media.fileSha256,
        fileEncSha256: media.fileEncSha256
      }
    } catch (error) { console.warn(`[THUMBNAIL] Upload HQ gagal, memakai preview biasa: ${error.message}`) }
    console.log(`[THUMBNAIL] source=${imageInfo.width || '?'}x${imageInfo.height || '?'} | sent=${finalInfo.width || '?'}x${finalInfo.height || '?'} | ratio=${options.ratio || 'auto'}`)
    let favicon
    if (options.icon) {
      try { favicon = await loadImage(options.icon) }
      catch (error) { console.warn(`[FAVICON] Icon diabaikan: ${error.message}`) }
    }
    const visibleText = String(text).trimStart().startsWith(url) ? String(text) : `${url}\n${text}`
    const content = {
      text: visibleText,
      ...(mentionsIn(visibleText, options.mentions).length ? { mentions: mentionsIn(visibleText, options.mentions) } : {}),
      linkPreview: {
        'matched-text': url,
        title: options.title || options.header || '',
        description: options.description || options.subTitle || '',
        jpegThumbnail,
        ...(highQualityThumbnail ? { highQualityThumbnail } : {}),
        previewType: options.previewType ?? (options.largeThumb ? 1 : 0)
      },
      ...(favicon ? { favicon } : {}),
      ...(options.contextInfo ? { contextInfo: options.contextInfo } : {})
    }
    const result = await sock.sendMessage(jid, content, options.relayOptions || {})
    console.log(`[SEND THUMBNAIL OK] target=${jid} | url=metadata-only`)
    return result
  }
  sock.sendMessageModify = async (jid, text, quoted, options = {}) => {
    const body = String(text)
    const previewUrl = options.url || Utils.generateLink(body)[0] || global.db?.setting?.link
    let thumbnail
    try {
      if (options.thumbnail) {
        const input = Buffer.isBuffer(options.thumbnail) ? options.thumbnail
          : Utils.isUrl(options.thumbnail) ? await Utils.fetchAsBuffer(options.thumbnail)
            : await fs.readFile(options.thumbnail)
        thumbnail = await sharp(input).resize(512, 512, { fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 82 }).toBuffer()
      }
    } catch (error) {
      console.warn(`[LINK PREVIEW] Thumbnail diabaikan: ${error.message}`)
    }
    if (options.type === 'preview-link' && options.thumbnail) {
      return sock.sendThumbnail(options.thumbnail, body, {
        ...options,
        jid,
        url: previewUrl,
        description: options.description || options.subTitle || global.footer || ''
      })
    }
    const linkPreview = options.linkPreview || (previewUrl ? {
      'matched-text': previewUrl,
      title: options.title || options.header || global.db?.setting?.sk_pack || 'WhatsApp Bot',
      description: options.description || options.content || '',
      jpegThumbnail: thumbnail,
      previewType: options.largeThumb ? 1 : 0
    } : undefined)
    const externalAdReply = previewUrl ? {
      title: options.title || options.header || body.split('\n').find(line => line.trim())?.trim() || 'WhatsApp Bot',
      body: options.description || options.subTitle || global.footer || '',
      url: previewUrl,
      ...(thumbnail ? { thumbnail } : {}),
      largeThumbnail: Boolean(options.largeThumb),
      mediaType: 1,
      showAdAttribution: Boolean(options.ads)
    } : undefined
    const isPreviewLink = options.type === 'preview-link'
    const mentions = mentionsIn(body, options.mentions)
    const content = {
      text: body,
      ...(mentions.length ? { mentions } : {}),
      ...(!isPreviewLink && linkPreview ? { linkPreview } : {}),
      ...(externalAdReply ? { externalAdReply } : {}),
      ...(options.contextInfo ? { contextInfo: options.contextInfo } : {})
    }
    try {
      return await sock.sendMessage(jid, content, quoted ? { quoted } : {})
    } catch (error) {
      console.error(`[SEND ERROR] ${jid}: ${error?.stack || error}`)
      throw error
    }
  }
  sock.copyNForward = async (jid, message) => {
    const content = await generateForwardMessageContent(message, false)
    const generated = generateWAMessageFromContent(jid, content, { userJid: sock.user?.id })
    return sock.relayMessage(jid, generated.message, { messageId: generated.key.id })
  }
  sock.resolveGroupMetadata = jid => sock.groupMetadata(jid)
  sock.fetchBlocklist = async () => nativeFetchBlocklist ? nativeFetchBlocklist() : []
  sock.decodeJid = jid => jid ? jidNormalizedUser(jid) : jid
  sock.getRealJid = jid => global.db?.users?.find(user => user.lid === jid)?.jid || jid
  sock.getUserId = async jid => {
    const ids = await sock.findUserId(jid).catch(() => null)
    return { jid: ids?.phoneNumber || sock.decodeJid(jid), lid: ids?.lid || null }
  }
  sock.getJidFromParticipants = (_chat, jid) => ({ id: sock.decodeJid(jid) })
  sock.lidParser = list => list.map(p => {
    const phoneNumber = p.phoneNumber ? sock.decodeJid(p.phoneNumber) : null
    const lid = p.lid || (String(p.id || '').endsWith('@lid') ? p.id : null)
    const ids = [phoneNumber, lid, sock.decodeJid(p.id)].filter(Boolean)
    for (const id of ids) mentionIndex.set(String(id).replace(/@.+/, ''), id)
    return { ...p, id: phoneNumber || sock.decodeJid(p.id || lid), phoneNumber, lid, ids }
  })
  sock.getAdmin = participants => participants
    .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    .flatMap(p => p.ids || [p.id])
  sock.profilePicture = jid => sock.profilePictureUrl(jid, 'image').catch(() => null)
  sock.getName = jid => global.db?.users?.find(user => user.jid === jid || user.lid === jid)?.name || store.contacts[jid]?.name || null
  sock.getJid = (_m, input) => input?.includes('@') ? input : input ? `${String(input).replace(/\D/g, '')}@s.whatsapp.net` : null
  return sock
}

async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState(path.join(root, 'session'))
  const { version } = await fetchLatestBaileysVersion()
  const phoneNumber = String(Config.pairing.number || '').replace(/\D/g, '')
  const usePairingCode = Boolean(phoneNumber)
  const sock = decorate(makeWASocket({
    auth: state,
    version,
    browser: Config.pairing.browser,
    printQRInTerminal: !usePairingCode,
    logger: pino({ level: 'silent' }),
    syncFullHistory: false,
    markOnlineOnConnect: Config.pairing.state
  }))
  store.bind(sock.ev)
  sock.ev.on('creds.update', saveCreds)

  let pairingRequested = false
  sock.ev.on('connection.update', async update => {
    const { connection, lastDisconnect } = update
    if (connection === 'connecting' && usePairingCode && !sock.authState.creds.registered && !pairingRequested) {
      pairingRequested = true
      try {
        await Utils.delay(1500)
        const preferredCode = String(Config.pairing.code || '').replace(/\s/g, '').toUpperCase()
        const code = preferredCode.length === 8
          ? await sock.requestPairingCode(phoneNumber, preferredCode)
          : await sock.requestPairingCode(phoneNumber)
        console.log('\n╔════════════════════════════════════╗')
        console.log(`║  KODE PAIRING: ${String(code).toUpperCase().padEnd(20)}║`)
        console.log('╚════════════════════════════════════╝')
        console.log('WhatsApp > Perangkat tertaut > Tautkan dengan nomor telepon.\n')
      } catch (error) {
        pairingRequested = false
        console.error('[PAIRING] Gagal membuat kode:', error?.message || error)
        console.error('[PAIRING] Pastikan pairing.number di lib/config.js memakai nomor dengan kode negara (contoh: 62812xxxx), tanpa tanda +.')
      }
    }
    if (connection === 'open') console.log('WhatsApp connected. Database: JSON')
    if (connection === 'close') {
      const loggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
      console.log(loggedOut ? 'Logged out. Hapus folder session/ lalu jalankan ulang untuk pairing lagi.' : 'Connection closed; reconnecting...')
      if (!loggedOut) setTimeout(connect, 3000)
    }
  })

  const pluginRegistry = {}
  const pluginManager = createPluginManager(path.join(root, 'plugins'), pluginRegistry)
  await pluginManager.start()
  console.log(`[PLUGIN] ${Object.keys(pluginRegistry).length} plugin aktif. Perubahan file plugins akan dimuat ulang otomatis.`)

  sock.ev.on('group-participants.update', async update => {
    try {
      const { id: groupId, action, participants = [] } = update || {}
      if (!groupId || !['add', 'remove'].includes(action)) return
      let groupSet = global.db?.groups?.find(group => group.jid === groupId)
      if (!groupSet) {
        groupSet = { jid: groupId, ...structuredClone(models.groups) }
        global.db.groups.push(groupSet)
      }
      if (action === 'add') {
        const addHooks = Object.entries(pluginRegistry).filter(([, mod]) => typeof mod.onGroupAdd === 'function')
        if (addHooks.length) {
          await Promise.all(participants.flatMap(participant => addHooks.map(async ([pluginPath, plugin]) => {
            try { await plugin.onGroupAdd({ client: sock, groupId, member: participant, Utils, system }) }
            catch (error) { console.error(`[GROUP ADD PLUGIN ERROR] ${pluginPath}\n${error?.stack || error}`) }
          })))
        }
      }
      const enabled = action === 'add' ? groupSet.welcome : groupSet.left
      if (!enabled) return
      const metadata = await sock.groupMetadata(groupId).catch(() => null)
      const subject = metadata?.subject || 'this'
      const template = action === 'add'
        ? (groupSet.text_welcome || 'Thanks +tag for joining into +grup group.')
        : (groupSet.text_left || 'Good bye +tag :)')
      for (const participant of participants) {
        const rawId = typeof participant === 'string'
          ? participant
          : participant?.phoneNumber || participant?.id || participant?.lid
        if (!rawId) {
          console.warn(`[GROUP ${action.toUpperCase()}] ID peserta kosong:`, participant)
          continue
        }
        let memberId = sock.decodeJid(rawId)
        if (String(memberId).endsWith('@lid')) {
          const resolved = await sock.findUserId(memberId).catch(() => null)
          memberId = resolved?.phoneNumber || memberId
        }
        const number = String(memberId).replace(/@.+/, '')
        if (!number) {
          console.warn(`[GROUP ${action.toUpperCase()}] Tidak dapat membuat mention untuk:`, participant)
          continue
        }
        const text = template.replaceAll('+tag', `@${number}`).replaceAll('+grup', subject)
        if (action === 'remove') {
          groupSet.member = groupSet.member || {}
          groupSet.member[memberId] = { ...(groupSet.member[memberId] || {}), left: true, lastseen: Date.now() }
        } else if (groupSet.member?.[memberId]) {
          groupSet.member[memberId].left = false
        }
        await sock.reply(groupId, text, null, { mentions: [memberId] })
        console.log(`[GROUP ${action.toUpperCase()}] group=${groupId} member=${memberId}`)
      }
      system.database.schedule()
    } catch (error) {
      console.error(`[WELCOME/LEAVE ERROR] ${error?.stack || error}`)
    }
  })

  sock.ev.on('messages.update', async updates => {
    if (!updates?.length) return
    await Promise.all(updates.map(async item => {
      try {
        const protocol = item.update?.message?.protocolMessage
        const isRevoke = item.update?.messageStubType === WAMessageStubType.REVOKE
        const revokedKey = isRevoke ? item.key : protocol?.key
        if (!revokedKey?.id) return
        console.log(`[DELETE EVENT] target=${cacheKey(revokedKey)} revoke=${isRevoke}`)
        const original = deletedMessageCache.get(cacheKey(revokedKey))
        if (!original) {
          console.warn(`[DELETE] Pesan ${cacheKey(revokedKey)} tidak ada di cache; tidak dapat dipulihkan.`)
          return
        }
        const deleteHooks = Object.entries(pluginRegistry).filter(([, mod]) => typeof mod.onDelete === 'function')
        await Promise.all(deleteHooks.map(async ([pluginPath, plugin]) => {
          try {
            await plugin.onDelete({ client: sock, message: original, revokedKey, Utils, system })
          } catch (error) {
            console.error(`[DELETE PLUGIN ERROR] ${pluginPath}\n${error?.stack || error}`)
          }
        }))
      } catch (error) { console.error(`[DELETE EVENT ERROR] ${error?.stack || error}`) }
    }))
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const raw of messages) {
      if (!raw.message || raw.key.remoteJid === 'status@broadcast') continue
      try {
        rememberMessage(raw)
        const m = await resolveMessageLids(sock, makeMessage(raw, sock))

        // Sticker commands
        const stickerHash = m.mtype === 'stickerMessage' && m.msg?.fileSha256
          ? m.msg.fileSha256.toString().replace(/,/g, '')
          : null
        const stickerAction = stickerHash ? global.db?.sticker?.[stickerHash]?.text : null
        if (stickerAction && typeof stickerAction === 'string') {
          const configuredPrefixes = global.db.setting?.prefix || ['.']
          const isSavedCommand = configuredPrefixes.some(prefix => stickerAction.startsWith(prefix)) || /^[+-]/.test(stickerAction)
          if (isSavedCommand) {
            m.body = stickerAction
            console.log(`[STICKER COMMAND] ${stickerHash} -> ${stickerAction}`)
          } else {
            await sock.reply(m.chat, stickerAction, m)
            console.log(`[STICKER TEXT] ${stickerHash}`)
            system.database.schedule()
            continue
          }
        }

        const body = String(m.body || '').trim()
        const setting = global.db.setting
        const prefixes = setting.prefix || ['.']
        const prefix = prefixes.find(p => body.startsWith(p)) || (Config.evaluate_chars || []).find(p => body.startsWith(p)) || ''
        const words = (prefix ? body.slice(prefix.length) : body).trim().split(/\s+/)
        const command = words.shift()?.toLowerCase() || ''

        // Kumpulkan semua command yang terdaftar termasuk hidden alias
        const commands = [...new Set(Object.values(pluginRegistry).flatMap(p => {
          const normalize = value => Array.isArray(value) ? value : value ? [value] : []
          return [...normalize(p.run.usage), ...normalize(p.run.hidden)]
        }))]

        logMessage(raw, m, body, prefix, command, words)

        // Jalankan onMessage hooks untuk semua pesan tanpa delay
        // Plugin yang export onMessage akan menerima setiap pesan masuk
        const messageHooks = Object.entries(pluginRegistry).filter(([, mod]) => typeof mod.onMessage === 'function')
        if (messageHooks.length) {
          // Fire and forget — tidak memblokir handler command utama
          Promise.all(
            messageHooks.map(async ([pluginPath, plugin]) => {
              try {
                await plugin.onMessage({
                  client: sock,
                  m,
                  body,
                  prefix,
                  prefixes,
                  command,
                  args: words,
                  text: words.join(' '),
                  commands,
                  plugins: pluginRegistry,
                  store,
                  system,
                  Utils
                })
              } catch (error) {
                console.error(`[MESSAGE HOOK ERROR] ${pluginPath}\n${error?.stack || error}`)
              }
            })
          ).catch(error => console.error(`[MESSAGE HOOKS ERROR] ${error?.stack || error}`))
        }

        // Handler utama tetap berjalan seperti semula untuk semua pesan
        await handler(sock, {
          m,
          body,
          prefix,
          prefixes,
          command,
          args: words,
          text: words.join(' '),
          commands,
          plugins: pluginRegistry,
          core: { prefix, command },
          store,
          system
        })

        system.database.schedule()
      } catch (error) { Utils.printError(error) }
    }
  })
}

const startWithRecovery = () => connect().catch(error => {
  Utils.printError(error)
  console.warn('[RECOVERY] Startup gagal; mencoba menyambung kembali dalam 5 detik.')
  setTimeout(startWithRecovery, 5000)
})
startWithRecovery()