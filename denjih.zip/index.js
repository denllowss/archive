import { spawn } from 'node:child_process'
import fs from 'node:fs/promises'
import path from 'node:path'
import CFonts from 'cfonts'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const tempDir = path.join(__dirname, 'temp')
async function cleanTemp() {
  await fs.mkdir(tempDir, { recursive: true })
  for (const name of await fs.readdir(tempDir)) if (!name.endsWith('.file')) await fs.rm(path.join(tempDir, name), { recursive: true, force: true })
}
if (Number(process.versions.node.split('.')[0]) < 20) throw new Error(`Node.js 20+ is required (current: ${process.versions.node}).`)
await cleanTemp(); setInterval(() => cleanTemp().catch(console.error), 60 * 60 * 1000)
CFonts.say('WHATSAPP BOT', { font: 'tiny', align: 'center', colors: ['system'] })
const child = spawn(process.argv[0], [path.join(__dirname, 'client.js'), ...process.argv.slice(2)], { stdio: 'inherit' })
child.on('exit', code => { if (code) console.error(`Bot exited with code ${code}`) })
