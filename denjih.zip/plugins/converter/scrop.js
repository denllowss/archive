import sharp from 'sharp'

const styles = [
   'triangle', 'circle', 'pentagon', 'star', 'hexagon', 'octagon',
   'spider', 'broken', 'love', 'diamond', 'cross', 'arrow',
   'moon', 'cloud', 'flower', 'shield', 'crown', 'lightning',
   'infinity', 'parallelogram', 'trapezoid', 'semicircle', 'donut',
   'leaf', 'clover', 'badge', 'ribbon', 'wave', 'arc', 'pill'
]

const polygon = (sides, size, radius = size / 2, start = -Math.PI / 2) =>
   Array.from({ length: sides }, (_, i) => {
      const angle = start + (i * Math.PI * 2 / sides)
      return `${size / 2 + radius * Math.cos(angle)},${size / 2 + radius * Math.sin(angle)}`
   }).join(' ')

function makeMask(style, size) {
   const c = size / 2 // center

   switch (style) {

      // ────────────────────────────────────────────
      //  BASIC SHAPES
      // ────────────────────────────────────────────

      case 'circle':
         return svg(size, `<circle cx="${c}" cy="${c}" r="${c}" fill="white"/>`)

      case 'triangle':
         // equilateral triangle pointing up
         return svg(size, `<polygon points="${c},0 ${size},${size} 0,${size}" fill="white"/>`)

      case 'diamond':
         // rotated square / rhombus
         return svg(size, `<polygon points="${c},0 ${size},${c} ${c},${size} 0,${c}" fill="white"/>`)

      case 'pentagon':
         return svg(size, `<polygon points="${polygon(5, size)}" fill="white"/>`)

      case 'hexagon':
         // flat-top hexagon
         return svg(size, `<polygon points="${polygon(6, size, c, 0)}" fill="white"/>`)

      case 'octagon':
         return svg(size, `<polygon points="${polygon(8, size, c, Math.PI / 8)}" fill="white"/>`)

      case 'trapezoid':
         // wider on bottom
         return svg(size, `<polygon points="${size * .15},${size} ${size * .85},${size} ${size * .65},0 ${size * .35},0" fill="white"/>`)

      case 'parallelogram':
         return svg(size, `<polygon points="${size * .25},0 ${size},0 ${size * .75},${size} 0,${size}" fill="white"/>`)

      case 'semicircle':
         // flat edge on top, dome on bottom
         return svg(size, `<path d="M0,${c} A${c},${c} 0 0,1 ${size},${c} L${size},${c} L0,${c}Z M0,${c} H${size} V${size} H0Z" fill="white"/>`)

      case 'pill':
         // tall pill / stadium shape
         return svg(size, `<rect x="${size * .2}" y="0" width="${size * .6}" height="${size}" rx="${size * .3}" ry="${size * .3}" fill="white"/>`)

      // ────────────────────────────────────────────
      //  STARS & EMBLEMS
      // ────────────────────────────────────────────

      case 'star': {
         // classic 5-pointed star
         const pts = Array.from({ length: 10 }, (_, i) => {
            const angle = i * Math.PI / 5 - Math.PI / 2
            const r = i % 2 === 0 ? c : c * .4
            return `${c + r * Math.cos(angle)},${c + r * Math.sin(angle)}`
         }).join(' ')
         return svg(size, `<polygon points="${pts}" fill="white"/>`)
      }

      case 'badge': {
         // 12-pointed star badge (gear-like)
         const pts = Array.from({ length: 24 }, (_, i) => {
            const angle = i * Math.PI / 12 - Math.PI / 2
            const r = i % 2 === 0 ? c : c * .82
            return `${c + r * Math.cos(angle)},${c + r * Math.sin(angle)}`
         }).join(' ')
         return svg(size, `<polygon points="${pts}" fill="white"/>`)
      }

      case 'crown':
         // 5-point crown with flat base
         return svg(size, `<polygon points="0,${size} 0,${size * .45} ${c * .5},${size * .72} ${c},${size * .08} ${c * 1.5},${size * .72} ${size},${size * .45} ${size},${size}" fill="white"/>`)

      case 'shield':
         // classic heater shield
         return svg(size, `<path d="M${c},${size * .98} C${c},${size * .98} ${size * .04},${size * .72} ${size * .04},${size * .32} L${size * .04},${size * .1} L${size * .96},${size * .1} L${size * .96},${size * .32} C${size * .96},${size * .72} ${c},${size * .98} ${c},${size * .98}Z" fill="white"/>`)

      case 'ribbon':
         // hexagonal ribbon / chevron tag
         return svg(size, `<polygon points="${size * .12},0 ${size * .88},0 ${size},${c} ${size * .88},${size} ${size * .12},${size} 0,${c}" fill="white"/>`)

      // ────────────────────────────────────────────
      //  ARROWS & SYMBOLS
      // ────────────────────────────────────────────

      case 'arrow':
         // right-pointing arrow
         return svg(size, `<polygon points="0,${size * .3} ${size * .55},${size * .3} ${size * .55},${size * .08} ${size},${c} ${size * .55},${size * .92} ${size * .55},${size * .7} 0,${size * .7}" fill="white"/>`)

      case 'cross':
         // plus / medical cross
         return svg(size, `<path d="M${size * .35},0 H${size * .65} V${size * .35} H${size} V${size * .65} H${size * .65} V${size} H${size * .35} V${size * .65} H0 V${size * .35} H${size * .35}Z" fill="white"/>`)

      case 'lightning':
         // bold lightning bolt
         return svg(size, `<polygon points="${size * .62},0 ${size * .2},${size * .52} ${size * .46},${size * .52} ${size * .38},${size} ${size * .8},${size * .48} ${size * .54},${size * .48}" fill="white"/>`)

      case 'infinity': {
         // figure-8 / lemniscate drawn as two offset ellipses
         const rx = size * .27, ry = size * .18
         const lx = c - size * .18, rx2 = c + size * .18
         return svg(size,
            `<ellipse cx="${lx}" cy="${c}" rx="${rx}" ry="${ry}" fill="white"/>` +
            `<ellipse cx="${rx2}" cy="${c}" rx="${rx}" ry="${ry}" fill="white"/>`
         )
      }

      case 'donut':
         // ring / annulus – white ring, transparent hole
         return svg(size,
            `<circle cx="${c}" cy="${c}" r="${c}" fill="white"/>` +
            `<circle cx="${c}" cy="${c}" r="${c * .38}" fill="black"/>`
         )

      // ────────────────────────────────────────────
      //  NATURE
      // ────────────────────────────────────────────

      case 'love':
         // heart
         return svg(size, `<path d="M${c},${size * .85} C${size * .08},${size * .58} ${size * .08},${size * .18} ${size * .3},${size * .18} C${size * .44},${size * .18} ${c},${size * .3} ${c},${size * .36} C${c},${size * .3} ${size * .56},${size * .18} ${size * .7},${size * .18} C${size * .92},${size * .18} ${size * .92},${size * .58} ${c},${size * .85}Z" fill="white"/>`)

      case 'moon':
         // crescent moon (pac-man subtraction trick)
         return svg(size,
            `<circle cx="${c}" cy="${c}" r="${c * .9}" fill="white"/>` +
            `<circle cx="${c * 1.35}" cy="${c * .65}" r="${c * .7}" fill="black"/>`
         )

      case 'leaf':
         // pointed oval leaf
         return svg(size, `<path d="M${c},0 C${size * .95},${size * .05} ${size},${size * .4} ${c},${size} C0,${size * .4} ${size * .05},${size * .05} ${c},0Z" fill="white"/>`)

      case 'cloud': {
         // 4-bubble cloud
         const r1 = size * .18, r2 = size * .22, r3 = size * .16
         return svg(size,
            `<circle cx="${size * .28}" cy="${size * .58}" r="${r1}" fill="white"/>` +
            `<circle cx="${size * .45}" cy="${size * .44}" r="${r2}" fill="white"/>` +
            `<circle cx="${size * .63}" cy="${size * .42}" r="${r2}" fill="white"/>` +
            `<circle cx="${size * .78}" cy="${size * .55}" r="${r3}" fill="white"/>` +
            `<rect x="${size * .18}" y="${size * .54}" width="${size * .65}" height="${size * .2}" fill="white"/>`
         )
      }

      case 'flower': {
         // 6 round petals + center
         const petals = Array.from({ length: 6 }, (_, i) => {
            const angle = i * Math.PI / 3
            const px = c + c * .45 * Math.cos(angle)
            const py = c + c * .45 * Math.sin(angle)
            return `<circle cx="${px}" cy="${py}" r="${size * .22}" fill="white"/>`
         }).join('')
         return svg(size, `${petals}<circle cx="${c}" cy="${c}" r="${size * .2}" fill="white"/>`)
      }

      case 'clover': {
         // 4 round leaves + tiny stem
         const leaves = Array.from({ length: 4 }, (_, i) => {
            const angle = i * Math.PI / 2 - Math.PI / 4
            const lx = c + size * .22 * Math.cos(angle)
            const ly = c + size * .22 * Math.sin(angle)
            return `<circle cx="${lx}" cy="${ly}" r="${size * .23}" fill="white"/>`
         }).join('')
         return svg(size,
            `${leaves}` +
            `<rect x="${c - size * .03}" y="${c + size * .2}" width="${size * .06}" height="${size * .25}" rx="${size * .03}" fill="white"/>` +
            `<circle cx="${c}" cy="${c}" r="${size * .1}" fill="white"/>`
         )
      }

      // ────────────────────────────────────────────
      //  ABSTRACT
      // ────────────────────────────────────────────

      case 'spider': {
         // real spider: oval body + head + 8 bent legs
         const legLen1 = size * .32, legLen2 = size * .28
         const legAngles = [-70, -40, -15, 20, 160, 195, 220, 250].map(d => d * Math.PI / 180)
         const legs = legAngles.map((a, i) => {
            // legs come from abdomen sides (left 4, right 4)
            const side = i < 4 ? -1 : 1
            const startX = c + side * size * .1
            const startY = c + size * .08
            // elbow (mid point bent outward)
            const midA = a + (side < 0 ? -0.4 : 0.4)
            const midX = startX + legLen1 * Math.cos(a)
            const midY = startY + legLen1 * Math.sin(a)
            const endX = midX + legLen2 * Math.cos(midA + (side < 0 ? 0.6 : -0.6))
            const endY = midY + legLen2 * Math.sin(midA + (side < 0 ? 0.6 : -0.6))
            return `<polyline points="${startX},${startY} ${midX},${midY} ${endX},${endY}" stroke="white" stroke-width="${size * .04}" stroke-linecap="round" fill="none"/>`
         }).join('')
         const abdomen = `<ellipse cx="${c}" cy="${c + size * .1}" rx="${size * .17}" ry="${size * .22}" fill="white"/>`
         const head = `<circle cx="${c}" cy="${c - size * .14}" r="${size * .13}" fill="white"/>`
         return svg(size, `${legs}${abdomen}${head}`)
      }

      case 'broken':
         // two rectangles – top-right and bottom-left
         return svg(size, `<rect x="0" y="0" width="${c - size * .03}" height="${size}" fill="white"/><rect x="${c + size * .03}" y="0" width="${c - size * .03}" height="${c}" fill="white"/>`)

      case 'wave':
         // horizontal wave band
         return svg(size, `<path d="M0,${size * .28} C${size * .12},${size * .1} ${size * .25},${size * .1} ${size * .37},${size * .28} C${size * .5},${size * .46} ${size * .62},${size * .46} ${size * .75},${size * .28} C${size * .87},${size * .1} ${size},${size * .1} ${size},${size * .28} L${size},${size * .72} C${size * .87},${size * .9} ${size * .75},${size * .9} ${size * .62},${size * .72} C${size * .5},${size * .54} ${size * .37},${size * .54} ${size * .25},${size * .72} C${size * .12},${size * .9} 0,${size * .9} 0,${size * .72}Z" fill="white"/>`)

      case 'arc':
         // thick arc / horseshoe
         return svg(size,
            `<circle cx="${c}" cy="${c}" r="${c * .9}" fill="white"/>` +
            `<circle cx="${c}" cy="${c}" r="${c * .55}" fill="black"/>` +
            `<rect x="0" y="${c}" width="${size}" height="${c}" fill="black"/>`
         )

      case 'semicircle':
         // dome up
         return svg(size, `<path d="M0,${c} A${c},${c} 0 0,1 ${size},${c} Z" fill="white"/><rect x="0" y="${c}" width="${size}" height="${c}" fill="white"/>`)

      default:
         throw new Error(`Style "${style}" tidak dikenali.`)
   }
}

// helper – wraps shape in SVG boilerplate
function svg(size, shape) {
   return Buffer.from(
      `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">` +
      `<rect width="100%" height="100%" fill="transparent"/>` +
      `${shape}</svg>`
   )
}

async function cropShape(buffer, style) {
   const metadata = await sharp(buffer).metadata()
   const size = Math.min(metadata.width || 0, metadata.height || 0)
   if (!size) throw new Error('Ukuran gambar tidak dapat dibaca.')
   const left = Math.floor(((metadata.width || size) - size) / 2)
   const top = Math.floor(((metadata.height || size) - size) / 2)
   return sharp(buffer)
      .extract({ left, top, width: size, height: size })
      .composite([{ input: makeMask(style, size), blend: 'dest-in' }])
      .png()
      .toBuffer()
}

export const run = {
   usage: ['scrop'],
   use: 'style',
   category: 'converter',
   async: async (m, { client, args, isPrefix, command, Utils }) => {
      try {
         const list = [...styles].sort()
         const col = Math.ceil(list.length / 2)
         const rows = Array.from({ length: col }, (_, i) => {
            const a = (isPrefix + command + ' ' + list[i]).padEnd(24)
            const b = list[i + col] ? isPrefix + command + ' ' + list[i + col] : ''
            const prefix = i === 0 ? '┌' : i === col - 1 ? '└' : '│'
            return `${prefix}  ◦  ${a}${b}`
         }).join('\n')
         const guide = `Use this feature based on the style below :\n\n${rows}\n\n${global.footer}`

         const selected = String(args?.[0] || '').toLowerCase()
         if (!selected || !styles.includes(selected))
            return client.sendFile(m.chat, 'https://iili.io/HtfsWdv.jpg', 'scrop.jpg', guide, m)

         const q = m.quoted || m
         const mime = (q.msg || q).mimetype || ''
         if (!/image\/(jpe?g|png)/i.test(mime))
            return client.reply(m.chat, Utils.texted('bold', '🚩 Reply photo (JPG/PNG).'), m)

         await client.sendReact(m.chat, '🕒', m.key)
         const result = await cropShape(await q.download(), selected)
         const setting = global.db.setting
         await client.sendSticker(m.chat, result, m, {
            packname: setting.sk_pack,
            author: setting.sk_author,
            meta: true
         })
      } catch (error) {
         console.error(`[SCROP ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 SCrop failed: ${error?.message || String(error)}`, m)
      }
   },
   error: false,
   limit: true
}