export const run = {
   usage: ['iqc'],
   use: 'text',
   category: 'convert',
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         if (!text) return client.reply(m.chat, Utils.example(isPrefix, command, `Hai kamu cantik banget`), m)
         client.sendReact(m.chat, '🕒', m.key)
         let old = new Date()

         const [chat, chatTime, statusBarTime] = text.split('|').map(v => v?.trim())

         // Waktu WIB Indonesia otomatis
         const now = new Date()
         const wibTime = now.toLocaleTimeString('id-ID', {
            timeZone: 'Asia/Jakarta',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
         })

         const params = new URLSearchParams({
            text: chat,
            chatTime: chatTime || wibTime,
            statusBarTime: statusBarTime || wibTime
         })

         const url = `https://api.deline.web.id/maker/iqc?${params}`

         const res = await fetch(url)
         const arrayBuffer = await res.arrayBuffer()
         const buffer = Buffer.from(arrayBuffer)

         client.sendFile(m.chat, buffer, 'iqc.png', `🍟 *Fetching* : ${new Date - old} ms`, m)
      } catch (e) {
         console.log(e)
         return client.reply(m.chat, Utils.jsonFormat(e), m)
      }
   },
   error: false,
   limit: true
}