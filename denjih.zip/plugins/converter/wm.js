export const run = {
   usage: ['take', 'swm'],
   hidden: ['wm'],
   use: 'packname | author',
   category: 'converter',
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         if (!text) return m.reply('Berikan teks untuk membuat watermark.')
         let [packname, ...author] = text.split`|`
         author = (author || []).join`|`

         // Command take - untuk mengubah watermark sticker yang sudah ada
         if (command === 'take' || command === 'wm') {
            let q = m.quoted ? m.quoted : m
            let mime = (q.msg || q).mimetype || ''
            if (!/webp/.test(mime)) return m.reply('Reply sticker yang ingin diubah watermarknya.')
            let img = await q.download()
            if (!img) return m.reply(global.status.wrong)
            return await client.sendSticker(m.chat, img, m, {
               packname: packname || '',
               author: author || ''
            })
         }

         // Command swm - untuk membuat sticker dari gambar/video
         if (command === 'swm') {
            if (m.quoted ? m.quoted.message : m.msg.viewOnce) {
               let type = m.quoted ? Object.keys(m.quoted.message)[0] : m.mtype
               let q = m.quoted ? m.quoted.message[type] : m.msg
               let img = await client.downloadMediaMessage(q)
               if (/video/.test(type)) {
                  if (q.seconds > 10) return m.reply('Durasi video maksimal 10 detik.')
                  return await client.sendSticker(m.chat, img, m, {
                     packname: packname || '',
                     author: author || ''
                  })
               } else if (/image/.test(type)) {
                  return await client.sendSticker(m.chat, img, m, {
                     packname: packname || '',
                     author: author || ''
                  })
               }
            } else {
               let q = m.quoted ? m.quoted : m
               let mime = (q.msg || q).mimetype || ''
               if (/image\/(jpe?g|png)/.test(mime)) {
                  let img = await q.download()
                  if (!img) return m.reply(global.status.wrong)
                  return await client.sendSticker(m.chat, img, m, {
                     packname: packname || '',
                     author: author || ''
                  })
               } else if (/video/.test(mime)) {
                  if ((q.msg || q).seconds > 10) return m.reply('Durasi video maksimal 10 detik.')
                  let img = await q.download()
                  if (!img) return m.reply(global.status.wrong)
                  return await client.sendSticker(m.chat, img, m, {
                     packname: packname || '',
                     author: author || ''
                  })
               } else m.reply(`Untuk membuat watermark pada sticker reply media foto atau video dan gunakan format *${isPrefix + command} packname | author*`)
            }
         }
      } catch (e) {
         console.log(e)
         return m.reply(Utils.jsonFormat(e))
      }
   },
   error: false,
   premium: true,
   limit: true
}