export const run = {
   usage: ['tiktok', 'tikmp3', 'tikwm'],
   hidden: ['tt'],
   use: 'link',
   category: 'downloader',
   async: async (m, {
      client,
      args,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         if (!args || !args[0]) return client.reply(m.chat, Utils.example(isPrefix, command, 'https://vm.tiktok.com/ZSR7c5G6y/'), m)
         if (!args[0].match('tiktok.com')) return client.reply(m.chat, global.status.invalid, m)
         client.sendReact(m.chat, '🕒', m.key)
         let old = new Date()

         const response = await fetch(`https://api.nexray.eu.cc/downloader/tiktok?url=${encodeURIComponent(Utils.ttFixed(args[0]))}`)
         const json = await response.json()

         if (!json.status) return m.reply(Utils.jsonFormat(json))

         const result = json.result

         if (command == 'tiktok' || command == 'tt') {
            // Cek apakah video (data berupa string) atau foto (data berupa array)
            if (typeof result.data === 'string') {
               return client.sendFile(m.chat, result.data, 'video.mp4', `🍟 *Fetching* : ${((new Date - old) * 1)} ms`, m)
            } else if (Array.isArray(result.data)) {
               for (let p of result.data) {
                  client.sendFile(m.chat, p, 'image.jpg', `🍟 *Fetching* : ${((new Date - old) * 1)} ms`, m)
                  await Utils.delay(1500)
               }
            }
         }

         if (command == 'tikwm') {
            // tikwm menggunakan video dengan watermark, fallback ke data jika size_wm tersedia
            if (typeof result.data !== 'string') return client.reply(m.chat, global.status.fail, m)
            return client.sendFile(m.chat, result.data, 'video.mp4', `🍟 *Fetching* : ${((new Date - old) * 1)} ms`, m)
         }

         if (command == 'tikmp3') {
            const audio = result?.music_info?.url
            return !audio
               ? client.reply(m.chat, global.status.fail, m)
               : client.sendFile(m.chat, audio, 'audio.mp3', '', m)
         }

      } catch (e) {
         return client.reply(m.chat, Utils.jsonFormat(e), m)
      }
   },
   error: false,
   limit: true
}