export const run = {
   usage: ['pin'],
   hidden: ['pinterest'],
   use: 'link or query',
   category: 'downloader',
   async: async (m, {
      client,
      args,
      text,
      isPrefix,
      command,
      Utils
   }) => {
      try {
         if (!text) return client.reply(m.chat, Utils.example(isPrefix, command, 'kucing'), m)
         client.sendReact(m.chat, '🕒', m.key)
         let old = new Date()
         
         if (Utils.isUrl(text.trim())) {
            // Untuk URL Pinterest (download)
            if (!text.match(/pin(?:terest)?(?:\.it|\.com)/)) return m.reply(global.status.invalid)
            const [url] = args
            const json = await Api.neoxr('/pin', { url })
            if (!json.status) return client.reply(m.chat, Utils.jsonFormat(json), m)
            if (json.data?.length === 1) return client.sendFile(m.chat, json.data[0].url, '', `Fetching : ${((new Date - old) * 1)} ms`, m)
            const files = json.data.map(v => ({ url: v.url }))
            client.sendAlbumMessage(m.chat, files, m)
         } else {
            // Untuk teks pencarian (search)
            const response = await fetch(`https://api.nexray.eu.cc/search/pinterest?q=${encodeURIComponent(text.trim())}`)
            const json = await response.json()
            
            if (!json.status) return client.reply(m.chat, Utils.jsonFormat(json), m)
            if (!json.result || json.result.length === 0) return client.reply(m.chat, 'Tidak ada hasil ditemukan.', m)
            
            // Ambil gambar secara random dari hasil
            const randomResult = Utils.random(json.result)
            const imgUrl = randomResult.images_url
            
            // Buat caption dengan info tambahan
            const caption = `Fetching : ${((new Date - old) * 1)} ms\n\n` +
                          `Title: ${randomResult.grid_title || 'N/A'}\n` +
                          `Description: ${randomResult.description || 'N/A'}\n` +
                          `Pinner: ${randomResult.pinner?.full_name || 'N/A'}\n` +
                          `Reactions: ${randomResult.reaction_counts?.[1] || 0}`
            
            client.sendFile(m.chat, imgUrl, '', caption, m)
         }
      } catch (e) {
         console.error(e)
         client.reply(m.chat, global.status.error, m)
      }
   },
   error: false,
   limit: true
}