import { Converter } from '../../lib/core.js'

export const run = {
   usage: ['play'],
   use: 'query',
   category: 'downloader',
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      users,
      setting,
      Config,
      Utils
   }) => {
      try {
         if (!text) return client.reply(m.chat, Utils.example(isPrefix, command, 'lathi'), m)
         await client.sendReact(m.chat, '🕒', m.key)

         const response = await fetch(`https://api.neoxr.eu/api/play?q=${encodeURIComponent(text)}&apikey=Exjfjg`)
         if (!response.ok) throw new Error(`YTPlay API HTTP ${response.status}`)
         const json = await response.json()
         if (!json.status) return client.reply(m.chat, Utils.jsonFormat(json), m)

         const result = json
         if (!result?.data?.url) throw new Error('YTPlay API tidak mengirim download URL.')

         let fileSize = null
         let fileSizeText = result.data.size || 'Unknown'
         
         // Parse size from API response (e.g., "3.7 MB")
         const sizeMatch = result.data.size?.match(/([\d.]+)\s*(MB|KB)/i)
         if (sizeMatch) {
            const sizeValue = parseFloat(sizeMatch[1])
            const sizeUnit = sizeMatch[2].toUpperCase()
            fileSize = sizeUnit === 'MB' ? sizeValue * 1024 * 1024 : sizeValue * 1024
         }

         // Fallback: get file size from HEAD request if not in API response
         if (!fileSize) {
            try {
               const head = await fetch(result.data.url, { method: 'HEAD', redirect: 'follow' })
               const contentLength = head.headers.get('content-length')
               if (contentLength) {
                  fileSize = Number.parseInt(contentLength, 10)
                  fileSizeText = `${(fileSize / (1024 * 1024)).toFixed(2)} MB`
               }
            } catch { }
         }

         if (fileSize) {
            const fileSizeMB = fileSize / (1024 * 1024)
            const maxLimit = users.premium ? Config.max_upload : Config.max_upload_free
            if (fileSizeMB > maxLimit) {
               const isOver = users.premium
                  ? `💀 File size (${fileSizeText}) exceeds the maximum limit.`
                  : `⚠️ File size (${fileSizeText}), you can only download files with a maximum size of ${Config.max_upload_free} MB and for premium users a maximum of ${Config.max_upload} MB.`
               return client.reply(m.chat, isOver, m)
            }
         }

         let caption = '乂  Y T - P L A Y\n\n'
         caption += `◦  Title : ${result.title || '-'}\n`
         caption += `◦  Channel : ${result.channel || '-'}\n`
         caption += `◦  Duration : ${result.duration || '-'}\n`
         caption += `◦  Views : ${result.views || '-'}\n`
         caption += `◦  Quality : ${result.data.quality || '-'}\n`
         caption += `◦  Size : ${fileSizeText}\n\n`
         caption += global.footer

         const baseName = String(result.title || 'audio').replace(/[^\w\s]/gi, '').trim() || 'audio'
         
         // Start media and cover downloads immediately
         const sourcePromise = Utils.fetchAsBuffer(result.data.url)
         const coverPromise = result.thumbnail
            ? Utils.fetchAsBuffer(result.thumbnail).catch(error => {
               console.warn(`[PLAY] Thumbnail diabaikan: ${error.message}`)
               return null
            })
            : Promise.resolve(null)

         await client.sendMessageModify(m.chat, caption, m, {
            largeThumb: true,
            type: 'preview-link',
            ratio: 'landscape',
            thumbnail: result.thumbnail,
            icon: setting.icon ? Utils.isUrl(setting.icon) ? setting.icon : Buffer.from(setting.icon, 'base64') : null
         })

         const [sourceMedia, apic] = await Promise.all([sourcePromise, coverPromise])
         const jpegThumbnail = apic ? await Utils.generateImageThumbnail(apic) : undefined
         const header = sourceMedia.subarray(0, 12)
         const isMp3 = header.subarray(0, 3).toString() === 'ID3' || header[0] === 0xff && (header[1] & 0xe0) === 0xe0
         const isOgg = header.subarray(0, 4).toString() === 'OggS'
         const isWav = header.subarray(0, 4).toString() === 'RIFF' && sourceMedia.subarray(8, 12).toString() === 'WAVE'
         
         // Avoid FFmpeg entirely when the API already delivered real audio
         const audio = isMp3 || isOgg || isWav ? sourceMedia : await Converter.toAudio(sourceMedia, 'mp3')
         const extension = result.data.extension || (isOgg ? 'ogg' : isWav ? 'wav' : 'mp3')
         const mimetype = isOgg ? 'audio/ogg' : isWav ? 'audio/wav' : 'audio/mpeg'
         
         await client.sendFile(m.chat, audio, `${baseName}.${extension}`, '', m, {
            audio: true,
            mimetype,
            ptt: false,
            APIC: apic
         }, {
            jpegThumbnail
         })
      } catch (error) {
         console.error(`[PLAY ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Play failed: ${error?.message || String(error)}`, m)
      }
   },
   error: false,
   restrict: true,
   limit: true
}