export const run = {
   usage: ['profile', 'me'],
   use: 'mention / reply / number (optional)',
   category: 'user info',
   async: async (m, { client, text, blockList, Config, Utils, users }) => {
      try {
         const self = !text && !m.quoted && !(m.mentionedJid?.length)
         let user = m.sender
         let target = users
         let name = m.pushName

         if (!self) {
            if (m.quoted?.sender) user = m.quoted.sender
            else if (m.mentionedJid?.[0]) user = m.mentionedJid[0]
            else {
               const number = String(text || '').replace(/[^0-9]/g, '')
               if (!number || number.length > 15) return client.reply(m.chat, Utils.texted('bold', '🚩 Invalid number.'), m)
               user = `${number}@s.whatsapp.net`
            }
            target = global.db.users.find(item => item.jid === user || item.lid === user)
            if (!target) return client.reply(m.chat, Utils.texted('bold', "🚩 Can't find user data."), m)
            name = target.name || user.replace(/@.+/, '')
         }

         global.Economy?.ensureUser(target)
         const now = Date.now()
         const group = m.isGroup ? global.db.groups.find(item => item.jid === m.chat) : null
         const warning = m.isGroup ? (group?.member?.[user]?.warning || 0) : (target.warning || 0)
         const temporaryLeft = (target.ban_temporary || 0) + Config.timeout - now
         const temporaryBan = target.ban_temporary > 0 && temporaryLeft > 0
         const job = target.job ? Utils.ucword(target.job) : 'Unemployed'
         const cooldown = Math.max(0, (target.workCooldown || 0) - now)
         const transition = Math.max(0, (target.resignCooldown || 0) - now)
         const activity = timestamp => {
            if (!timestamp) return 'Never'
            const elapsed = Math.max(0, now - timestamp)
            const date = new Intl.DateTimeFormat('id-ID', {
               timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit',
               hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
            }).format(new Date(timestamp))
            return `${Utils.toTime(elapsed)} ago (${date} WIB)`
         }

         let caption = '乂  U S E R - P R O F I L E\n\n'
         caption += `◦ Name : ${name}\n`
         caption += `◦ Limit : ${Utils.formatNumber(target.limit || 0)}\n`
         caption += `◦ Hitstat : ${Utils.formatNumber(target.hit || 0)}\n`
         caption += `◦ Warning : ${warning} / 5\n\n`
         caption += '乂  E C O N O M Y\n\n'
         caption += `◦ Money : ${Utils.formatNumber(target.money || 0)}\n`
         caption += `◦ Bank : ${Utils.formatNumber(target.bank || 0)}\n`
         caption += `◦ Job : ${job}\n`
         caption += `◦ Job Level : ${target.job ? (target.jobLevel || 1) : '-'}\n`
         caption += `◦ Job XP : ${target.job ? `${target.jobXp || 0}/${(target.jobLevel || 1) * 100}` : '-'}\n`
         caption += `◦ Reputation : ${target.reputation ?? 50}/100\n`
         caption += `◦ Energy : ${target.energy ?? 100}/100\n`
         caption += `◦ Work Cooldown : ${cooldown ? global.Economy.formatDuration(cooldown) : '-'}\n`
         caption += `◦ Career Transition : ${transition ? global.Economy.formatDuration(transition) : '-'}\n\n`
         caption += '乂  U S E R - S T A T U S\n\n'
         caption += `◦ Blocked : ${blockList.includes(user) ? 'Yes' : 'No'}\n`
         caption += `◦ Banned : ${temporaryBan ? `Temporary (${global.Economy.formatDuration(temporaryLeft)} left)` : target.banned ? 'Permanent' : 'No'}\n`
         caption += `◦ Premium : ${target.premium ? 'Yes' : 'No'}\n`
         caption += `◦ Expired : ${target.expired ? Utils.toTime(Math.max(0, target.expired - now)) : 'No Expiry'}\n\n`
         caption += '乂  U S E R - A C T I V I T Y\n\n'
         caption += `◦ Last Seen : ${activity(target.lastseen)}\n`
         caption += `◦ Last Use Bot : ${activity(target.usebot)}\n\n`
         caption += global.footer

         // Profile/me intentionally sends text only: no thumbnail, image,
         // preview link, or external media payload.
         await client.reply(m.chat, caption, m)
      } catch (error) {
         console.error(`[PROFILE ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Profile failed: ${error?.message || String(error)}`, m)
      }
   },
   error: false
}
