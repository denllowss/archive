export const run = {
   usage: ['limit', 'money'],
   hidden: ["bal", "balance", "mymoney", "mybal"],
   category: 'user info',
   async: async (m, {
      client,
      isPrefix,
      users,
      Utils
   }) => {
      if (users.limit < 1) return client.reply(m.chat, `🚩 Your bot usage has reached the limit and will be reset at 00.00\n\nTo get more limits, upgrade to a premium plan send *${isPrefix}premium*`, m)
      
      let message = `🍟 Your limit : [ *${Utils.formatNumber(users.limit)}* ]\n`
      message += `💰 Your money : [ *${Utils.formatNumber(users.money || 0)}* ]`
      message += `${!users.premium ? `\n\nTo get more limits, upgrade to a premium plan send *${isPrefix}premium*` : ''}`
      
      client.reply(m.chat, message, m)
   },
   error: false
}