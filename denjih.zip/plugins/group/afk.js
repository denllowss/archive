import fs from 'node:fs'
import path from 'node:path'

const afkPath = path.resolve(process.cwd(), 'database/afk.json')
const loadAfk = () => {
   try {
      if (fs.existsSync(afkPath)) return JSON.parse(fs.readFileSync(afkPath, 'utf8')) || {}
   } catch (error) { console.warn(`[AFK] Read failed: ${error.message}`) }
   return {}
}
const saveAfk = data => {
   try {
      fs.mkdirSync(path.dirname(afkPath), { recursive: true })
      const temporary = `${afkPath}.tmp`
      fs.writeFileSync(temporary, JSON.stringify(data, null, 2))
      fs.renameSync(temporary, afkPath)
   } catch (error) { console.error(`[AFK] Save failed: ${error.message}`) }
}

export const run = {
   usage: ['afk'],
   use: 'reason (optional)',
   category: 'group',
   async: async (m, { client, text, Utils }) => {
      try {
         const data = loadAfk()
         data[m.sender] ||= {}
         data[m.sender][m.chat] = { 
            afk: Date.now(), 
            reason: String(text || ''),
            mentions: [] // Array untuk menyimpan siapa yang mention
         }
         saveAfk(data)
         const tag = m.sender.replace(/@.+/, '')
         await client.reply(m.chat, Utils.texted('bold', `🚩 @${tag} is now AFK!${text ? `\n• Reason : ${text}` : ''}`), m, { mentions: [m.sender] })
      } catch (error) {
         console.error(`[AFK SET ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 AFK failed: ${error?.message || String(error)}`, m)
      }
   },
   error: false,
   group: true
}

export const event = {
   group: true,
   always: true,
   async: async (m, { client, Utils, body, prefix, command }) => {
      try {
         const data = loadAfk()
         const ownStatus = data?.[m.sender]?.[m.chat]
         const isSettingAfk = command === 'afk' && (prefix || String(body || '').trim().startsWith('.afk'))
         
         // Cek jika user kembali dari AFK
         if (ownStatus?.afk && !isSettingAfk) {
            const duration = Utils.toTime(Date.now() - ownStatus.afk)
            const reason = ownStatus.reason || '-'
            const mentions = ownStatus.mentions || []
            
            // Buat pesan recap
            let recapMsg = `🚩 @${m.sender.replace(/@.+/, '')} is no longer AFK.\n\n`
            recapMsg += `• Duration : ${duration}\n`
            recapMsg += `• Reason : ${reason}\n`
            
            // Tambahkan recap mention jika ada
            if (mentions.length > 0) {
               recapMsg += `\n📨 *Recap Mentions* (${mentions.length}):\n`
               const uniqueMentions = {}
               
               // Group by sender untuk menghitung berapa kali masing-masing orang mention
               mentions.forEach(m => {
                  const key = m.from
                  if (!uniqueMentions[key]) {
                     uniqueMentions[key] = { count: 0, lastTime: 0 }
                  }
                  uniqueMentions[key].count++
                  uniqueMentions[key].lastTime = Math.max(uniqueMentions[key].lastTime, m.time)
               })
               
               // Tampilkan recap
               Object.entries(uniqueMentions).forEach(([jid, info], idx) => {
                  const tag = jid.replace(/@.+/, '')
                  const timeAgo = Utils.toTime(Date.now() - info.lastTime)
                  recapMsg += `${idx + 1}. @${tag} (${info.count}x) - ${timeAgo} ago\n`
               })
               
               // Ambil semua JID untuk mention
               const mentionJids = [m.sender, ...Object.keys(uniqueMentions)]
               await client.reply(m.chat, recapMsg, m, { mentions: mentionJids })
            } else {
               await client.reply(m.chat, recapMsg, m, { mentions: [m.sender] })
            }
            
            // Hapus status AFK
            delete data[m.sender][m.chat]
            if (Object.keys(data[m.sender]).length === 0) delete data[m.sender]
            saveAfk(data)
         }
         
         // Deteksi mention ke user yang AFK
         const targets = [...new Set([...(m.mentionedJid || []), ...(m.quoted?.sender ? [m.quoted.sender] : [])])]
         for (const jid of targets) {
            const status = data?.[jid]?.[m.chat]
            if (!status?.afk || status.afk < 0 || m.fromMe || jid === m.sender) continue
            
            const number = jid.replace(/@.+/, '')
            
            // Tampilkan status AFK di grup
            await client.reply(
               m.chat, 
               `*Away From Keyboard* : @${number}\n• Reason : ${status.reason || '-'}\n• Duration : [ ${Utils.toTime(Date.now() - status.afk)} ]`, 
               m, 
               { mentions: [jid] }
            )
            
            // Simpan informasi mention ke data AFK (TANPA kirim pesan pribadi)
            if (!data[jid][m.chat].mentions) data[jid][m.chat].mentions = []
            data[jid][m.chat].mentions.push({
               from: m.sender,
               time: Date.now(),
               group: m.chat
            })
            saveAfk(data)
         }
      } catch (error) {
         console.error(`[AFK DETECTOR ERROR] ${error?.stack || error}`)
      }
   }
}