const DAILY_INTEREST = 0.005 // 0.5% daily; capped so the economy stays stable.
const MAX_INTEREST_DAYS = 30

function applyInterest(user) {
   const now = Date.now()
   const days = Math.min(MAX_INTEREST_DAYS, Math.floor((now - user.bankInterestAt) / 86400000))
   if (days <= 0 || user.bank <= 0) return 0
   const interest = Math.floor(user.bank * (Math.pow(1 + DAILY_INTEREST, days) - 1))
   user.bank += interest
   user.bankInterestAt += days * 86400000
   return interest
}
const amountOf = value => Number(String(value || '').replace(/[^0-9]/g, ''))

export const run = {
   usage: ['bank'],
   use: 'deposit / withdraw / transfer',
   category: 'economy',
   async: async (m, { client, args, users, Utils }) => {
      try {
         const Economy = global.Economy
         Economy.ensureUser(users)
         const interest = applyInterest(users)
         const action = String(args?.[0] || 'info').toLowerCase()

         if (['info', 'balance', 'saldo'].includes(action)) {
            return client.reply(m.chat,
               `🏦 *BANK ACCOUNT*\n\n` +
               `Cash: ${Utils.formatNumber(users.money)}\n` +
               `Bank: ${Utils.formatNumber(users.bank)}\n` +
               `Interest: 0.5% per hari\n` +
               `${interest ? `Interest received: +${Utils.formatNumber(interest)}\n` : ''}\n` +
               `Deposit: *.bank deposit <jumlah>*\n` +
               `Withdraw: *.bank withdraw <jumlah>*\n` +
               `Transfer: *.bank transfer @user <jumlah>*`,
               m
            )
         }

         if (['deposit', 'setor'].includes(action)) {
            const amount = amountOf(args?.[1])
            if (!amount || amount < 1) return client.reply(m.chat, '🚩 Masukkan jumlah deposit yang valid.', m)
            if (users.money < amount) return client.reply(m.chat, '🚩 Money tunai tidak cukup.', m)
            users.money -= amount
            users.bank += amount
            return client.reply(m.chat, `✅ Deposit berhasil.\n\nCash: ${Utils.formatNumber(users.money)}\nBank: ${Utils.formatNumber(users.bank)}`, m)
         }

         if (['withdraw', 'tarik'].includes(action)) {
            const amount = amountOf(args?.[1])
            if (!amount || amount < 1) return client.reply(m.chat, '🚩 Masukkan jumlah penarikan yang valid.', m)
            if (users.bank < amount) return client.reply(m.chat, '🚩 Saldo bank tidak cukup.', m)
            users.bank -= amount
            users.money += amount
            return client.reply(m.chat, `✅ Penarikan berhasil.\n\nCash: ${Utils.formatNumber(users.money)}\nBank: ${Utils.formatNumber(users.bank)}`, m)
         }

         if (['transfer', 'kirim'].includes(action)) {
            const targetJid = m.mentionedJid?.[0] || m.quoted?.sender
            const amount = amountOf(args?.[args.length - 1])
            if (!targetJid || targetJid === m.sender) return client.reply(m.chat, '🚩 Mention atau reply target transfer.', m)
            if (!amount || amount < 1) return client.reply(m.chat, '🚩 Masukkan jumlah transfer yang valid.', m)
            const target = global.db.users.find(user => user.jid === targetJid || user.lid === targetJid)
            if (!target) return client.reply(m.chat, '🚩 Data target tidak ditemukan.', m)
            Economy.ensureUser(target)
            applyInterest(target)
            const fee = Math.max(5, Math.ceil(amount * 0.01))
            const total = amount + fee
            if (users.bank < total) return client.reply(m.chat, `🚩 Saldo bank tidak cukup. Total dengan biaya transfer: ${Utils.formatNumber(total)}.`, m)
            users.bank -= total
            target.bank += amount
            return client.reply(m.chat, `✅ Transfer berhasil ke @${targetJid.replace(/@.+/, '')}.\n\nJumlah: ${Utils.formatNumber(amount)}\nBiaya transfer: ${Utils.formatNumber(fee)}\nSaldo bank: ${Utils.formatNumber(users.bank)}`, m, { mentions: [targetJid] })
         }

         return client.reply(m.chat, '🚩 Gunakan: info, deposit, withdraw, atau transfer.', m)
      } catch (error) {
         console.error(`[BANK ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Bank failed: ${error?.message || String(error)}`, m)
      }
   }
}
