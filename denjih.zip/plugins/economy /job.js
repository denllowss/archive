const JOBS = {
   farmer: { id: 'farmer', label: '🌾 Farmer', salary: 320, cooldown: 20 * 60000, demand: 1.15, energy: 14, xp: 10, minRep: 0, risk: 0.2 },
   courier: { id: 'courier', label: '🛵 Courier', salary: 430, cooldown: 25 * 60000, demand: 1.05, energy: 18, xp: 12, minRep: 10, risk: 0.25 },
   chef: { id: 'chef', label: '👨‍🍳 Chef', salary: 520, cooldown: 30 * 60000, demand: 1, energy: 20, xp: 14, minRep: 20, risk: 0.2 },
   mechanic: { id: 'mechanic', label: '🔧 Mechanic', salary: 680, cooldown: 35 * 60000, demand: .95, energy: 26, xp: 17, minRep: 30, risk: .3 },
   nurse: { id: 'nurse', label: '🩺 Nurse', salary: 760, cooldown: 40 * 60000, demand: 1.1, energy: 24, xp: 20, minRep: 40, risk: .15 },
   programmer: { id: 'programmer', label: '💻 Programmer', salary: 950, cooldown: 45 * 60000, demand: .9, energy: 22, xp: 24, minRep: 55, risk: .18 },
   architect: { id: 'architect', label: '🏗️ Architect', salary: 1100, cooldown: 55 * 60000, demand: .85, energy: 30, xp: 28, minRep: 70, risk: .25 }
}
const list = Utils => Object.values(JOBS).map(j => `• *${j.id}* — ${j.label}\n  Gaji: ${Utils.formatNumber(j.salary)} | Rep: ${j.minRep}+ | Energi: ${j.energy}`).join('\n\n')
export const run = {
 usage: ['kerja','job'], use: 'list / lamar <job> / resign / profile', category: 'economy',
 async: async (m,{client,args,users,Utils}) => { try {
  const E=global.Economy; E.ensureUser(users); const a=String(args?.[0]||'work').toLowerCase()
  if(['list','jobs','pekerjaan'].includes(a)) return client.reply(m.chat,`💼 *LOWONGAN*\n\n${list(Utils)}\n\nLamar: *.job lamar <nama>*`,m)
  if(['profile','profil'].includes(a)) return client.reply(m.chat,`💼 *KARIER*\n\nJob: ${users.job ? JOBS[users.job].label : '-'}\nLevel: ${users.jobLevel}\nXP: ${users.jobXp}/${users.jobLevel*100}\nReputasi: ${users.reputation}/100\nEnergi: ${users.energy}/100\nMoney: ${Utils.formatNumber(users.money)}\nTotal penghasilan: ${Utils.formatNumber(users.lifetimeEarnings)}`,m)
  if(['lamar','apply'].includes(a)) { const j=JOBS[String(args?.[1]||'').toLowerCase()]; if(!j)return client.reply(m.chat,'🚩 Job tidak tersedia.',m); if(users.job)return client.reply(m.chat,'🚩 Kamu harus resign dahulu.',m); const wait=users.resignCooldown-Date.now(); if(wait>0)return client.reply(m.chat,`⏳ Setelah resign kamu harus menunggu *${E.formatDuration(wait)}* sebelum melamar pekerjaan baru.`,m); if(users.reputation<j.minRep)return client.reply(m.chat,`🚩 Reputasi minimal untuk ${j.label}: ${j.minRep}.`,m); users.job=j.id;users.jobSince=Date.now();users.jobLevel=1;users.jobXp=0;return client.reply(m.chat,`✅ Lamaran diterima. Kamu resmi menjadi ${j.label}.${users.workCooldown>Date.now()?`\n\n⏳ Kamu masih memiliki cooldown kerja: *${E.formatDuration(users.workCooldown-Date.now())}*.`:''}`,m) }
  if(['resign','keluar','berhenti'].includes(a)) { if(!users.job)return client.reply(m.chat,'🚩 Kamu belum punya pekerjaan.',m); const old=JOBS[users.job].label; users.job=null;users.jobSince=0;users.jobLevel=1;users.jobXp=0; users.resignCooldown=Date.now()+30*60000; return client.reply(m.chat,`✅ Kamu resign dari ${old}.\n\n⏳ Masa transisi karier: *30 menit*. Cooldown kerja yang tersisa juga tetap berlaku.`,m) }
  if(!users.job)return client.reply(m.chat,'💼 Kamu belum bekerja. Ketik *.job list*.',m)
  const r=E.work(users,JOBS[users.job]); if(!r.ok)return client.reply(m.chat,r.energy?`⚡ Energi kurang. Butuh ${r.needed} energi lagi. Energi pulih 1 tiap 10 menit.`:`⏳ Istirahat ${E.formatDuration(r.remaining)}.`,m)
  await client.reply(m.chat,`💼 *SHIFT SELESAI*\n\n${r.job.label}\nBruto: ${Utils.formatNumber(r.gross)}\nPajak: -${Utils.formatNumber(r.tax)}\nGaji bersih: *+${Utils.formatNumber(r.income)}*\nXP: +${r.xp}${r.promoted?'\n🎉 Naik level karier!':''}\n\nMoney: ${Utils.formatNumber(users.money)}\nEnergi: ${users.energy}/100\nRep: ${users.reputation}/100\nEkonomi: ${r.market.condition}`,m)
 } catch(e){console.error('[JOB ERROR]',e);await client.reply(m.chat,`🚩 Job failed: ${e.message||e}`,m)} }
}
