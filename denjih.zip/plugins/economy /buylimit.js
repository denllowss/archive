export const run = {
   usage: ['buylimit', 'belilimit'],
   use: '<jumlah>',
   category: 'economy',
   async: async (m, { client, args, users, Utils }) => {
      try {
         const Economy = global.Economy
         Economy.ensureUser(users)
         const amount = Number(args?.[0])
         if (!Number.isInteger(amount) || amount < 1 || amount > 100) {
            const preview = Economy.limitPrice(users, 1)
            return client.reply(m.chat, `🛒 *TOKO LIMIT*\n\nHarga saat ini: *${Utils.formatNumber(preview.unit)} money* per limit\nEkonomi: *${preview.market.condition}*\n\nGunakan: *.buylimit <jumlah>*\nMaksimal 100 limit per transaksi.`, m)
         }
         const price = Economy.limitPrice(users, amount)
         if (users.money < price.total) {
            return client.reply(m.chat, `🚩 Money tidak cukup.\n\nHarga: *${Utils.formatNumber(price.total)}*\nMoney kamu: *${Utils.formatNumber(users.money)}*`, m)
         }
         users.money -= price.total
         users.limit = (users.limit || 0) + amount
         await client.reply(m.chat, `✅ Berhasil membeli *${amount} limit*.\n\nHarga: -${Utils.formatNumber(price.total)}\nLimit sekarang: *${Utils.formatNumber(users.limit)}*\nMoney tersisa: *${Utils.formatNumber(users.money)}*`, m)
      } catch (error) {
         console.error(`[BUYLIMIT ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Pembelian limit gagal: ${error?.message || String(error)}`, m)
      }
   }
}
