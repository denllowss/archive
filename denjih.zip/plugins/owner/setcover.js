import sharp from 'sharp'

export const run = {
   usage: ['setcover'],
   hidden: ['cover'],
   use: 'reply foto',
   category: 'owner',
   async: async (m, { client, setting, Utils }) => {
      try {
         const q = m.quoted || m
         const mime = (q.msg || q).mimetype || ''
         if (!/image/.test(mime)) return client.reply(m.chat, Utils.texted('bold', '🚩 Image not found.'), m)
         await client.sendReact(m.chat, '🕒', m.key)
         const buffer = await cropToLandscapeBuffer(await q.download())
         if (!buffer) throw new Error(global.status.wrong)
         setting.cover = Buffer.from(buffer).toString('base64')
         await client.reply(m.chat, Utils.texted('bold', '🚩 Cover successfully set.'), m)
      } catch (error) {
         console.error(`[SETCOVER ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Failed to set cover: ${error?.message || String(error)}`, m)
      }
   },
   owner: true
}

// Sharp is already a direct dependency of this standalone bot. It replaces
// Jimp, which was only an indirect dependency and caused ERR_MODULE_NOT_FOUND.
async function cropToLandscapeBuffer(inputBuffer, aspectRatio = 16 / 9, quality = 50) {
   const image = sharp(inputBuffer)
   const metadata = await image.metadata()
   const width = metadata.width
   const height = metadata.height
   if (!width || !height) throw new Error('Image dimension cannot be read.')

   const currentRatio = width / height
   const cropWidth = currentRatio > aspectRatio ? Math.floor(height * aspectRatio) : width
   const cropHeight = currentRatio > aspectRatio ? height : Math.floor(width / aspectRatio)
   const left = Math.max(0, Math.floor((width - cropWidth) / 2))
   const top = Math.max(0, Math.floor((height - cropHeight) / 2))

   return sharp(inputBuffer)
      .extract({ left, top, width: cropWidth, height: cropHeight })
      .jpeg({ quality })
      .toBuffer()
}
