export const run = {
   usage: ['+owner', '-owner', '-prem', 'block', 'unblock', 'ban', 'unban'],
   use: 'mention or reply',
   category: 'owner',
   async: async (m, {
      client,
      text,
      command,
      Config,
      Utils
   }) => {
      try {
         const input = m?.mentionedJid?.[0] || m?.quoted?.sender || text
         if (!input) return m.reply('Mention atau reply chat target.')
         const p = await client.onWhatsApp(input.trim())
         if (!p.length) return m.reply('Nomor tidak valid.')
         const jid = client.decodeJid(p[0].jid)
         const number = jid.replace(/@.+/, '')
         
         if (command == '+owner') {
            let owners = global.db.setting.owners
            if (owners.includes(number)) return m.reply('Target sudah menjadi owner.')
            owners.push(number)
            m.reply(`Berhasil menambahkan @${number} sebagai owner.`)
         } else if (command == '-owner') {
            let owners = global.db.setting.owners
            if (!owners.includes(number)) return m.reply('Target bukan owner.')
            owners.forEach((data, index) => {
               if (data === number) owners.splice(index, 1)
            })
            m.reply(`Berhasil menghapus @${number} dari daftar owner.`)
         } else if (command == '-prem') {
            let data = global.db.users.find(v => v.jid == jid)
            if (!data) return m.reply('Data user tidak ditemukan.')
            if (!data.premium) return m.reply('Bukan akun premium.')
            data.limit = Config.limit
            data.premium = false
            data.expired = 0
            m.reply(`Status premium @${number} berhasil dihapus.`)
         } else if (command == 'block') {
            if (jid == client.decodeJid(client.user.id)) return m.reply('Tidak bisa block diri sendiri.')
            await client.updateBlockStatus(jid, 'block')
            m.reply(`Berhasil memblokir @${number}`)
         } else if (command == 'unblock') {
            await client.updateBlockStatus(jid, 'unblock')
            m.reply(`Berhasil membuka blokir @${number}`)
         } else if (command == 'ban') {
            let is_user = global.db.users
            let is_owner = [client.decodeJid(client.user.id).split`@`[0], Config.owner, ...global.db.setting.owners].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(jid)
            if (!is_user.some(v => v.jid == jid)) return m.reply('Data user tidak ditemukan.')
            if (is_owner) return m.reply('Tidak bisa banned nomor owner.')
            if (jid == client.decodeJid(client.user.id)) return m.reply('Tidak bisa banned diri sendiri.')
            if (is_user.find(v => v.jid == jid).banned) return m.reply('Target sudah dibanned.')
            is_user.find(v => v.jid == jid).banned = true
            let banned = is_user.filter(v => v.banned).length
            m.reply(`Berhasil menambahkan @${number} ke daftar banned.\n\nTotal banned: ${banned}`)
         } else if (command == 'unban') {
            let is_user = global.db.users
            if (!is_user.some(v => v.jid == jid)) return m.reply('Data user tidak ditemukan.')
            if (!is_user.find(v => v.jid == jid).banned) return m.reply('Target tidak dibanned.')
            is_user.find(v => v.jid == jid).banned = false
            let banned = is_user.filter(v => v.banned).length
            m.reply(`Berhasil menghapus @${number} dari daftar banned.\n\nTotal banned: ${banned}`)
         }
      } catch (e) {
         m.reply(Utils.jsonFormat(e))
      }
   },
   error: false,
   owner: true
}