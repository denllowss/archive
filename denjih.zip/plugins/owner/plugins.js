import path from 'path'

export const run = {
   usage: ['plugen', 'plugdis', '+hidecategory', '-hidecategory'],
   use: 'plugin name / category name',
   category: 'owner',
   async: async (m, {
      client,
      args,
      text,
      isPrefix,
      prefix,
      command,
      ctx,
      setting,
      Utils
   }) => {
      try {
         // Plugin Enable/Disable
         if (command === 'plugen' || command === 'plugdis') {
            const [pluginName] = args
            if (!pluginName) return m.reply(Utils.example(isPrefix, command, 'tiktok'))

            let plugins = Object.keys(ctx.plugins).map(dir => path.basename(dir, '.js'))
            const regex = new RegExp(pluginName, 'i')

            if (command === 'plugdis') {
               const matched = plugins.filter(p => regex.test(p))

               if (matched.length === 0) return m.reply(`Plugin ${pluginName}.js tidak ditemukan.`)

               let disabledCount = 0
               for (const name of matched) {
                  if (!setting.pluginDisable.includes(name)) {
                     setting.pluginDisable.push(name)
                     disabledCount++
                  }
               }

               if (disabledCount === 0) return m.reply('Semua plugin yang cocok sudah dinonaktifkan.')

               m.reply(`${disabledCount} plugin berhasil dinonaktifkan.`)
            } else if (command === 'plugen') {
               const before = setting.pluginDisable.length

               setting.pluginDisable = setting.pluginDisable.filter(p => !regex.test(p))

               const after = setting.pluginDisable.length
               const enabledCount = before - after

               if (enabledCount === 0) return m.reply('Tidak ada plugin yang cocok dalam daftar nonaktif.')

               m.reply(`${enabledCount} plugin berhasil diaktifkan.`)
            }
         }

         // Hide/Unhide Category
         if (command === '+hidecategory' || command === '-hidecategory') {
            const categories = [...new Set(Object.values(Object.fromEntries(Object.entries(ctx.plugins).filter(([name, prop]) => prop.run.category))).map(v => v.run.category))]
            if (!text) return m.reply(Utils.example(prefix, command, 'features'))
            if (!categories.includes(text.toLowerCase().trim())) return m.reply(`Kategori ${text} tidak ditemukan.`)

            if (command === '+hidecategory') {
               if (setting.hidden.includes(text.toLowerCase().trim())) return m.reply(`Kategori ${text} sudah disembunyikan sebelumnya.`)
               setting.hidden.push(text.toLowerCase().trim())
               m.reply(`Kategori ${text} berhasil disembunyikan.`)
            } else if (command === '-hidecategory') {
               if (!setting.hidden.includes(text.toLowerCase().trim())) return m.reply(`Kategori ${text} tidak ada dalam daftar tersembunyi.`)
               setting.hidden.forEach((data, index) => {
                  if (data === text.toLowerCase().trim()) setting.hidden.splice(index, 1)
               })
               m.reply(`Kategori ${text} berhasil dihapus dari daftar tersembunyi.`)
            }
         }
      } catch (e) {
         m.reply(Utils.jsonFormat(e))
      }
   },
   owner: true
}