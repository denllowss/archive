import axios from 'axios'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

export const run = {
   usage: ['tourl'],
   hidden: ["tocatbox", "upload"],
   use: 'reply media',
   category: 'tools',
   async: async (m, {
      client,
      Utils
   }) => {
      try {
         let q = m.quoted ? m.quoted : m
         let mime = (q.msg || q).mimetype || ''
         
         if (!mime) return m.reply('Reply media (gambar/video/audio/dokumen) yang ingin diupload ke Catbox.')
         
         m.reply('Sedang mengupload ke Catbox...')
         
         let media = await q.download()
         if (!media) return m.reply('Gagal mendownload media.')
         
         const fileType = await fileTypeFromBuffer(media)
         const form = new FormData()
         form.append('reqtype', 'fileupload')
         form.append('fileToUpload', media, {
            filename: `file.${fileType?.ext || 'bin'}`,
            contentType: fileType?.mime || 'application/octet-stream'
         })
         
         const response = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
               ...form.getHeaders()
            }
         })
         
         if (response.data) {
            let caption = `Upload berhasil!\n\n`
            caption += `URL: ${response.data}\n`
            caption += `Type: ${fileType?.mime || 'unknown'}\n`
            caption += `Size: ${Utils.formatSize(media.length)}`
            
            m.reply(caption)
         } else {
            m.reply('Gagal mengupload ke Catbox.')
         }
         
      } catch (e) {
         console.log(e)
         return m.reply(`Terjadi kesalahan:\n${e.message || Utils.jsonFormat(e)}`)
      }
   },
   error: false,
   limit: true,
   premium: false
}