export const run = {
   usage: ['ping', 'bot'],
   category: 'miscs',
   async: async (m, { client }) => {
      try {
         const results = []
         const firstStart = Date.now()
         const message = await client.reply(m.chat, '🏓 Checking speed 1/3 ...', m)
         results.push(Date.now() - firstStart)

         for (let index = 2; index <= 3; index++) {
            await new Promise(resolve => setTimeout(resolve, 250))
            const start = Date.now()
            await client.sendMessage(m.chat, {
               text: `🏓 Checking speed ${index}/3 ...`,
               edit: message.key
            })
            results.push(Date.now() - start)
         }

         const average = Math.round(results.reduce((sum, value) => sum + value, 0) / results.length)
         await client.sendMessage(m.chat, {
            text: `✨ *PING RESULT*\n\n` +
               `1. ${results[0]} ms\n` +
               `2. ${results[1]} ms\n` +
               `3. ${results[2]} ms\n\n` +
               `Average: *${average} ms*`,
            edit: message.key
         })
      } catch (error) {
         console.error(`[PING ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Ping failed: ${error?.message || String(error)}`, m)
      }
   },
   error: false
}
