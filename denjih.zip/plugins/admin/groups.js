export const run = {
   usage: ['group'],
   hidden: ["grub", "gc", "groups", "groups"],
   use: 'open / close',
   category: 'admin tools',
   async: async (m, {
      client,
      args,
      Utils
   }) => {
      if (!args || !args[0]) return client.reply(m.chat, Utils.texted('bold', `🚩 Enter argument close or open.`), m)
      
      const arg = args[0].toLowerCase()
      
      if (arg == 'open' || arg == 'buka') {
         await client.groupSettingUpdate(m.chat, 'not_announcement')
         client.reply(m.chat, Utils.texted('bold', `✅ Grup berhasil dibuka!`), m)
      } else if (arg == 'close' || arg == 'tutup') {
         await client.groupSettingUpdate(m.chat, 'announcement')
         client.reply(m.chat, Utils.texted('bold', `✅ Grup berhasil ditutup!`), m)
      } else {
         client.reply(m.chat, Utils.texted('bold', `🚩 Argumen tidak valid. Gunakan: open/buka atau close/tutup`), m)
      }
   },
   group: true,
   admin: true,
   botAdmin: true
}