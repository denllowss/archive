export const run = {
   usage: ['sider'],
   use: '(option)',
   category: 'admin tools',
   admin: true,
   group: true,
   async: async (m, { client, args, isPrefix, command, participants, isBotAdmin, Utils }) => {
      try {
         const group = global.db.groups.find(item => item.jid === m.chat)
         if (!group) return client.reply(m.chat, '🚩 Group setting tidak ditemukan.', m)
         group.member ||= {}

         const botIds = [client.decodeJid(client.user?.id || ''), client.user?.lid].filter(Boolean)
         const members = participants
            .filter(participant => !participant.admin)
            .map(participant => {
               const ids = [...new Set(participant.ids || [participant.id])].filter(Boolean)
               const jid = ids.find(id => !botIds.includes(id)) || participant.id
               const recordKey = ids.find(id => group.member[id])
               return { jid, ids, record: recordKey ? group.member[recordKey] : null }
            })
            .filter(member => member.jid && !botIds.includes(member.jid))

         const now = Date.now()
         const oneWeek = 7 * 24 * 60 * 60 * 1000
         const noActivity = members.filter(member => !member.record)
         const inactive = members
            .filter(member => member.record?.lastseen > 0 && now - member.record.lastseen > oneWeek)
            .sort((a, b) => a.record.lastseen - b.record.lastseen)

         if (args?.[0] === '-y') {
            if (!isBotAdmin) return client.reply(m.chat, global.status.botAdmin, m)
            const candidates = [...new Map([...inactive, ...noActivity].map(member => [member.jid, member])).values()]
            if (!candidates.length) return client.reply(m.chat, Utils.texted('bold', '🚩 There is no sider in this group.'), m)

            let removed = 0
            for (const member of candidates) {
               try {
                  await client.groupParticipantsUpdate(m.chat, [member.jid], 'remove')
                  removed++
                  await Utils.delay(1500)
               } catch (error) {
                  console.warn(`[SIDER] Gagal menghapus ${member.jid}: ${error.message}`)
               }
            }
            return client.reply(m.chat, Utils.texted('bold', `🚩 Done, ${removed}/${candidates.length} siders successfully removed.`), m)
         }

         if (!noActivity.length && !inactive.length) return client.reply(m.chat, Utils.texted('bold', '🚩 There is no sider in this group.'), m)
         const mentionIds = [...new Set([...noActivity, ...inactive].map(member => member.jid))]
         let text = '乂  S I D E R\n\n'
         if (noActivity.length) {
            text += `“List of ${noActivity.length} members no activity.”\n\n`
            text += noActivity.map(member => `◦  @${member.jid.replace(/@.+/, '')}`).join('\n') + '\n\n'
         }
         if (inactive.length) {
            text += `“List of ${inactive.length} members not online for 1 week.”\n\n`
            text += inactive.map(member => {
               const days = Math.floor((now - member.record.lastseen) / 86400000)
               return `◦  @${member.jid.replace(/@.+/, '')}\n     *Lastseen* : ${days} days ago`
            }).join('\n') + '\n\n'
         }
         text += `*Note* : This feature will be accurate when the bot has been in the group for 1 week, send ${isPrefix + command} -y to remove them.\n\n${global.footer}`
         await client.reply(m.chat, text, m, { mentions: mentionIds })
      } catch (error) {
         console.error(`[SIDER ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Sider failed: ${error?.message || String(error)}`, m)
      }
   }
}
