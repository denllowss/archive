export const run = {
   usage: ['antidelete'],
   use: 'on / off',
   category: 'admin tools',
   group: true,
   admin: true,
   async: async (m, { client, args, command, Utils }) => {
      try {
         const setting = global.db.groups.find(group => group.jid === m.chat)
         if (!setting) return client.reply(m.chat, '🚩 Group setting tidak ditemukan.', m)

         const type = command.toLowerCase()
         const current = setting[type] ? 'ON' : 'OFF'
         const option = String(args?.[0] || '').toLowerCase()
         if (!option || !['on', 'off'].includes(option)) {
            return client.reply(m.chat, `🚩 Current status : [ ${current} ] (Enter On or Off)`, m)
         }

         const status = option === 'on'
         if (setting[type] === status) {
            return client.reply(m.chat, Utils.texted('bold', `🚩 ${Utils.ucword(command)} has been ${status ? 'activated' : 'inactivated'} previously.`), m)
         }
         setting[type] = status
         await client.reply(m.chat, Utils.texted('bold', `🚩 ${Utils.ucword(command)} has been ${status ? 'activated' : 'inactivated'} successfully.`), m)
      } catch (error) {
         console.error(`[ANTIDELETE ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Antidelete failed: ${error?.message || String(error)}`, m)
      }
   }
}

// This delete event lives with the command in the same plugin file. The client
// only dispatches native WhatsApp revoke events; all anti-delete behavior is
// controlled here by the group's antidelete setting.
const messageText = message => {
   // Text is captured at messages.upsert time, before the revoke update can
   // alter the raw protobuf object kept by the in-memory store.
   if (typeof message?._antiDeleteText === 'string' && message._antiDeleteText.trim()) return message._antiDeleteText
   const read = content => {
      if (!content || typeof content !== 'object') return ''
      if (typeof content.conversation === 'string') return content.conversation
      if (typeof content.extendedTextMessage?.text === 'string') return content.extendedTextMessage.text
      if (typeof content.imageMessage?.caption === 'string') return content.imageMessage.caption || '[ Image ]'
      if (content.imageMessage) return '[ Image ]'
      if (typeof content.videoMessage?.caption === 'string') return content.videoMessage.caption || '[ Video ]'
      if (content.videoMessage) return '[ Video ]'
      if (typeof content.documentMessage?.caption === 'string') return content.documentMessage.caption || `[ Document: ${content.documentMessage.fileName || 'file'} ]`
      if (content.documentMessage) return `[ Document: ${content.documentMessage.fileName || 'file'} ]`
      if (content.audioMessage) return '[ Audio ]'
      if (content.stickerMessage) return '[ Sticker ]'
      // WhatsApp often wraps ordinary text in these containers.
      for (const wrapper of ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'editedMessage']) {
         const nested = content[wrapper]?.message
         const value = read(nested)
         if (value) return value
      }
      // Last fallback: scan nested message objects for normal text/caption.
      for (const value of Object.values(content)) {
         if (value && typeof value === 'object' && !Buffer.isBuffer(value)) {
            const result = read(value)
            if (result) return result
         }
      }
      return ''
   }
   const result = read(message?.message)
   if (!result) console.warn('[ANTIDELETE] Tidak dapat membaca pesan, keys:', Object.keys(message?.message || {}))
   return result || '[ Pesan tidak dapat ditampilkan ]'
}

export const onDelete = async ({ client, message }) => {
   const chat = message?.key?.remoteJid
   if (!chat?.endsWith('@g.us') || message.key?.fromMe) return
   const setting = global.db?.groups?.find(group => group.jid === chat)
   if (!setting?.antidelete) return

   const sender = client.decodeJid(message.key?.participantAlt || message.key?.participant || '')
   const tag = sender ? `@${sender.replace(/@.+/, '')}` : 'Unknown'
   const timestamp = Number(message.messageTimestamp || Date.now() / 1000) * 1000
   const time = new Intl.DateTimeFormat('id-ID', {
      timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
   }).format(new Date(timestamp))
   const text = `[ Anti - Delete ]\n\nTerdeteksi ${tag} telah menghapus pesan\n\nPesan: ${messageText(message)}\n\nWaktu: ${time} WIB`
   await client.reply(chat, text, null, { mentions: sender ? [sender] : [] })
   console.log(`[ANTIDELETE] Detected delete ${message.key?.id || '-'} in ${chat}`)
}
