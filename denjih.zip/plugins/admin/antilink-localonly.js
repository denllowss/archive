const urlPattern = /https?:\/\/[^\s]+/i
const normalizeLink = value => {
   try { return new URL(String(value).trim()).origin.toLowerCase() } catch { return String(value || '').trim().toLowerCase().replace(/\/$/, '') }
}

export const run = {
   usage: ['antilink', 'antilunk', 'localonly'],
   use: 'on/off, add/remove/list, country',
   category: 'admin tools',
   admin: true,
   group: true,
   async: async (m, { client, args, command, isBotAdmin, Utils }) => {
      try {
         const group = global.db.groups.find(item => item.jid === m.chat)
         if (!group) return client.reply(m.chat, '🚩 Group setting tidak ditemukan.', m)
         // Migrate prior model names safely.
         group.antilinkBlocked ||= []
         group.localonlyCountries ||= ['62']
         const rawType = command.toLowerCase()
         const type = rawType === 'antilunk' ? 'antilink' : rawType
         const action = String(args?.[0] || '').toLowerCase()
         if (!isBotAdmin) return client.reply(m.chat, global.status.botAdmin, m)

         if (type === 'antilink' && ['add', 'block'].includes(action)) {
            const link = normalizeLink(args?.slice(1).join(' '))
            if (!link || !/^https?:\/\//.test(link)) return client.reply(m.chat, '🚩 Gunakan: *.antilink add https://link.com*', m)
            if (!group.antilinkBlocked.includes(link)) group.antilinkBlocked.push(link)
            return client.reply(m.chat, `✅ Link terlarang ditambahkan: *${link}*`, m)
         }
         if (type === 'antilink' && ['remove', 'del', 'delete'].includes(action)) {
            const link = normalizeLink(args?.slice(1).join(' '))
            group.antilinkBlocked = group.antilinkBlocked.filter(item => item !== link)
            return client.reply(m.chat, `✅ Link terlarang dihapus: *${link}*`, m)
         }
         if (type === 'antilink' && ['list', 'blocked'].includes(action)) {
            return client.reply(m.chat, `🔗 *LINK TERLARANG*\n\n${group.antilinkBlocked.length ? group.antilinkBlocked.map((item, i) => `${i + 1}. ${item}`).join('\n') : 'Belum ada link terlarang.'}`, m)
         }

         if (type === 'localonly' && ['country', 'code'].includes(action)) {
            const operation = String(args?.[1] || '').toLowerCase()
            const code = String(args?.[2] || '').replace(/\D/g, '')
            if (operation === 'list') return client.reply(m.chat, `🌍 Kode negara diizinkan: *${group.localonlyCountries.join(', ')}*`, m)
            if (!code) return client.reply(m.chat, '🚩 Contoh Indonesia: *.localonly country add 62*', m)
            if (['add', 'allow'].includes(operation)) { if (!group.localonlyCountries.includes(code)) group.localonlyCountries.push(code); return client.reply(m.chat, `✅ Kode negara *${code}* ditambahkan.`, m) }
            if (['remove', 'del', 'delete'].includes(operation)) { if (group.localonlyCountries.length <= 1) return client.reply(m.chat, '🚩 Minimal satu kode negara harus tetap diizinkan.', m); group.localonlyCountries = group.localonlyCountries.filter(item => item !== code); return client.reply(m.chat, `✅ Kode negara *${code}* dihapus.`, m) }
            return client.reply(m.chat, '🚩 Gunakan add/remove/list.', m)
         }

         if (!['on', 'off'].includes(action)) return client.reply(m.chat, `🚩 Current status : [ ${group[type] ? 'ON' : 'OFF'} ]\n\nAntilink: *.antilink add/remove/list*\nLocalonly: *.localonly country add/remove/list*`, m)
         group[type] = action === 'on'
         await client.reply(m.chat, `✅ ${Utils.ucword(type)} berhasil ${group[type] ? 'diaktifkan' : 'dinonaktifkan'}.`, m)
      } catch (error) {
         console.error(`[PROTECTION ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Protection failed: ${error?.message || String(error)}`, m)
      }
   }
}

export const event = {
   always: true,
   group: true,
   botAdmin: true,
   async: async (m, { client, body, groupSet, isAdmin, isOwner }) => {
      if (!groupSet?.antilink || isAdmin || isOwner || m.fromMe) return
      const url = String(body || m.msg?.name || '').match(urlPattern)?.[0]
      if (!url) return
      const blocked = groupSet.antilinkBlocked || []
      if (!blocked.includes(normalizeLink(url))) return
      try {
         await client.sendMessage(m.chat, { delete: m.key })
         await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
      } catch (error) { console.error(`[ANTILINK EVENT ERROR] ${error?.message || error}`) }
   }
}

export const onGroupAdd = async ({ client, groupId, member }) => {
   const group = global.db.groups.find(item => item.jid === groupId)
   if (!group?.localonly) return
   const jid = String(member?.phoneNumber || member?.id || member?.lid || member)
   const number = jid.replace(/@.+/, '')
   const allowed = group.localonlyCountries?.length ? group.localonlyCountries : ['62']
   if (allowed.some(code => number.startsWith(code))) return
   try {
      await client.reply(groupId, `🚩 @${number} tidak diizinkan. Kode negara yang diizinkan: ${allowed.join(', ')}.`, null, { mentions: [jid] })
      await client.groupParticipantsUpdate(groupId, [jid], 'remove')
   } catch (error) { console.error(`[LOCALONLY EVENT ERROR] ${error?.message || error}`) }
}
