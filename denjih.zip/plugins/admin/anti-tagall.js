export const run = {
   usage: ['antitagall'],
   hidden: ['anti-tagall'],
   use: 'on / off',
   category: 'admin tools',
   admin: true,
   group: true,
   async: async (m, { client, args, command, Utils }) => {
      try {
         const setting = global.db.groups.find(group => group.jid === m.chat)
         if (!setting) return client.reply(m.chat, '🚩 Group setting tidak ditemukan.', m)
         const option = String(args?.[0] || '').toLowerCase()
         if (!['on', 'off'].includes(option)) {
            return client.reply(m.chat, `🚩 Current status : [ ${setting.antitagall ? 'ON' : 'OFF'} ] (Enter On or Off)`, m)
         }
         const status = option === 'on'
         if (setting.antitagall === status) {
            return client.reply(m.chat, Utils.texted('bold', `🚩 ${Utils.ucword(command)} has been ${status ? 'activated' : 'inactivated'} previously.`), m)
         }
         setting.antitagall = status
         await client.reply(m.chat, Utils.texted('bold', `🚩 ${Utils.ucword(command)} has been ${status ? 'activated' : 'inactivated'} successfully.`), m)
      } catch (error) {
         console.error(`[ANTITAGALL ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Anti Tag All failed: ${error?.message || String(error)}`, m)
      }
   }
}

// Event remains in the same plugin file as the on/off command.
export const event = {
   group: true,
   botAdmin: true,
   async: async (m, { client, isAdmin, isOwner, groupSet }) => {
      try {
         if (!groupSet?.antitagall || isOwner || isAdmin) return
         const context = m.message?.[m.mtype || 'none']?.contextInfo || m.msg?.contextInfo || {}
         const tooManyMentions = (m.mentionedJid?.length || 0) > 10
         const tagAll = Boolean(context.nonJidMentions)
         if (!tooManyMentions && !tagAll) return
         await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
         console.log(`[ANTITAGALL] Removed ${m.sender} from ${m.chat}`)
      } catch (error) {
         console.error(`[ANTITAGALL EVENT ERROR] ${error?.stack || error}`)
      }
   }
}
