export const run = {
   usage: ['tagadmin'],
   hidden: ['tag-admin', 'tagadmins'],
   category: 'group',
   group: true,
   admin: true,
   async: async (m, { client, text }) => {
      try {
         const metadata = await client.groupMetadata(m.chat).catch(() => null)
         if (!metadata) return client.reply(m.chat, '[ ! ] Gagal mengambil data grup.', m)

         // Prefer PN when supplied by WA, and retain LID as a valid fallback.
         const admins = client.lidParser(metadata.participants || [])
            .filter(participant => participant.admin === 'admin' || participant.admin === 'superadmin')
            .map(participant => participant.phoneNumber || participant.id)
            .filter(Boolean)
         if (!admins.length) return client.reply(m.chat, '[ ! ] Tidak ada admin di grup ini.', m)

         const fallbackText = String(m.quoted?.text || m.quoted?.caption || '').trim()
         const messageText = String(text || '').trim() || fallbackText
         const list = admins.map(jid => `• @${jid.replace(/@.+/, '')}`).join('\n')
         const content = `*[ TAG ADMIN ]*${messageText ? `\n\n${messageText}` : ''}\n\n${list}`
         await client.sendMessage(m.chat, { text: content, mentions: admins }, { quoted: m })
      } catch (error) {
         console.error(`[TAGADMIN ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `[ ! ] Gagal menandai admin: ${error?.message || String(error)}`, m)
      }
   }
}
