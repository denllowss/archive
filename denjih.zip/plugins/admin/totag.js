import { generateForwardMessageContent, generateWAMessageFromContent } from 'baileys'

const ignoredKeys = new Set(['messageContextInfo', 'senderKeyDistributionMessage'])
const findMessageType = message => Object.keys(message || {}).find(key => !ignoredKeys.has(key) && message[key] != null)

// Add mentionedJid to every applicable contextInfo, including nested button,
// template and interactive message structures.
function injectMentions(value, mentions) {
   if (!value || typeof value !== 'object' || Buffer.isBuffer(value)) return
   if (Array.isArray(value)) return value.forEach(item => injectMentions(item, mentions))
   if (value.contextInfo && typeof value.contextInfo === 'object') value.contextInfo.mentionedJid = mentions
   for (const child of Object.values(value)) injectMentions(child, mentions)
}

export const run = {
   usage: ['totag'],
   hidden: ['totags'],
   category: 'group',
   group: true,
   admin: true,
   async: async (m, { client, Utils }) => {
      try {
         if (!m.quoted?.message) return client.reply(m.chat, '[ ! ] Reply pesan terlebih dahulu.', m)

         const metadata = await client.groupMetadata(m.chat).catch(() => null)
         if (!metadata) return client.reply(m.chat, '[ ! ] Gagal mengambil data grup.', m)

         const botJid = client.decodeJid(client.user?.id || '')
         const members = client.lidParser(metadata.participants || [])
            .flatMap(participant => participant.ids || [participant.id])
            .filter(jid => jid && jid !== botJid)
         const raw = structuredClone(m.quoted.message)
         const quotedType = findMessageType(raw)
         const quotedMentions = raw?.[quotedType]?.contextInfo?.mentionedJid || []
         const mentions = [...new Set([...members, ...quotedMentions])]

         // conversation has no contextInfo, so change it to extended text first.
         if (typeof raw.conversation === 'string') {
            raw.extendedTextMessage = { text: raw.conversation, contextInfo: { mentionedJid: mentions } }
            delete raw.conversation
         }
         injectMentions(raw, mentions)
         const targetType = findMessageType(raw)
         if (targetType && typeof raw[targetType] === 'object') {
            raw[targetType].contextInfo ||= {}
            raw[targetType].contextInfo.mentionedJid = mentions
         }

         // Use Baileys' own forward builder to retain media/interactive payloads.
         const forwarded = await generateForwardMessageContent({ key: m.quoted.key, message: raw }, false)
         injectMentions(forwarded, mentions)
         const forwardedType = findMessageType(forwarded)
         if (forwardedType && typeof forwarded[forwardedType] === 'object') {
            forwarded[forwardedType].contextInfo ||= {}
            forwarded[forwardedType].contextInfo.mentionedJid = mentions
         }
         const generated = generateWAMessageFromContent(m.chat, forwarded, { userJid: client.user?.id })
         await client.relayMessage(m.chat, generated.message, { messageId: generated.key.id })
      } catch (error) {
         console.error(`[TOTAG ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `[ ! ] Gagal mengirim pesan: ${error?.message || Utils.jsonFormat(error)}`, m)
      }
   }
}
