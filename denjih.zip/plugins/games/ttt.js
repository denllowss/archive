// One-file, group-scoped two-player Tic Tac Toe.
const games = global.tictactoeRooms ||= new Map()
const keyOf = m => m.chat
const tag = jid => `@${String(jid).replace(/@.+/, '')}`
const wins = [
   [0, 1, 2], [3, 4, 5], [6, 7, 8],
   [0, 3, 6], [1, 4, 7], [2, 5, 8],
   [0, 4, 8], [2, 4, 6]
]
const hasWon = (board, mark) => wins.some(line => line.every(index => board[index] === mark))
const numberEmoji = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣']
const markEmoji = { X: '❌', O: '⭕' }
const boardText = board => board.map((cell, index) => markEmoji[cell] || numberEmoji[index]).reduce((rows, cell, index) => {
   const row = Math.floor(index / 3)
   rows[row] ||= []
   rows[row].push(cell)
   return rows
}, []).map(row => row.join(' │ ')).join('\n───┼───┼───\n')
const clearTimer = game => { if (game.timer) clearTimeout(game.timer); game.timer = null }
function setChallengeTimeout(client, game, replyTo) {
   clearTimer(game)
   game.timer = setTimeout(async () => {
      if (games.get(game.chat) !== game || game.state !== 'waiting') return
      games.delete(game.chat)
      await client.reply(game.chat, '🎮 Room Tic Tac Toe kedaluwarsa karena tantangan tidak diterima selama 30 menit.', replyTo).catch(() => {})
   }, 30 * 60 * 1000)
}
function setTurnTimeout(client, game, replyTo) {
   clearTimer(game)
   game.timer = setTimeout(async () => {
      if (games.get(game.chat) !== game || game.state !== 'playing') return
      games.delete(game.chat)
      await client.reply(game.chat, '🎮 Game Tic Tac Toe dihapus karena tidak ada giliran yang dimainkan selama 10 menit.', replyTo).catch(() => {})
   }, 10 * 60 * 1000)
}
async function showBoard(client, game, replyTo, extra = '') {
   const player = game.turn === 'X' ? game.x : game.o
   const text = `🎮 *TIC TAC TOE*\n\n${tag(game.x)} : ❌\n${tag(game.o)} : ⭕\n\n${boardText(game.board)}\n\n${extra}${extra ? '\n\n' : ''}Giliran: ${tag(player)} (${game.turn})\nKetik angka *1-9* untuk memilih kotak.`
   await client.reply(game.chat, text, replyTo, { mentions: [game.x, game.o, player] })
   setTurnTimeout(client, game, replyTo)
}

export const run = {
   usage: ['tictactoe'],
   hidden: ['ttt'],
   use: '@player / accept / reject / cancel',
   category: 'games',
   group: true,
   async: async (m, { client, text, Utils }) => {
      try {
         const roomId = keyOf(m)
         const option = String(text || '').trim().toLowerCase()
         const game = games.get(roomId)

         if (['accept', 'terima'].includes(option)) {
            if (!game || game.state !== 'waiting') return client.reply(m.chat, '🎮 Tidak ada tantangan Tic Tac Toe.', m)
            if (m.sender !== game.o) return client.reply(m.chat, '🎮 Hanya pemain yang ditantang yang dapat menerima.', m)
            clearTimer(game)
            game.state = 'playing'
            game.board = Array(9).fill(null)
            game.turn = 'X'
            return showBoard(client, game, m, '✅ Tantangan diterima!')
         }
         if (['reject', 'tolak', 'cancel', 'batal', 'stop'].includes(option)) {
            if (!game) return client.reply(m.chat, '🎮 Tidak ada room Tic Tac Toe.', m)
            if (![game.x, game.o].includes(m.sender)) return client.reply(m.chat, '🎮 Hanya pemain room yang dapat membatalkan.', m)
            clearTimer(game)
            games.delete(roomId)
            return client.reply(m.chat, '🎮 Tic Tac Toe dibatalkan.', m)
         }
         if (game) return client.reply(m.chat, '🎮 Room Tic Tac Toe sudah digunakan. Selesaikan atau batalkan terlebih dahulu.', m)

         const opponent = m.mentionedJid?.[0] || m.quoted?.sender
         if (!opponent) return client.reply(m.chat, Utils.example('.', 'tictactoe', '@player'), m)
         if (opponent === m.sender) return client.reply(m.chat, '🎮 Kamu tidak dapat menantang diri sendiri.', m)
         if (opponent === client.decodeJid(client.user?.id || '')) return client.reply(m.chat, '🎮 Bot tidak dapat menjadi pemain.', m)

         const room = { chat: m.chat, x: m.sender, o: opponent, state: 'waiting', board: [], turn: 'X', timer: null }
         games.set(roomId, room)
         setChallengeTimeout(client, room, m)
         await client.reply(m.chat, `🎮 ${tag(m.sender)} menantang ${tag(opponent)} bermain *Tic Tac Toe*!\n\n${tag(opponent)}, ketik *.ttt accept* untuk menerima atau *.ttt reject* untuk menolak.`, m, { mentions: [m.sender, opponent] })
      } catch (error) {
         console.error(`[TICTACTOE ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🎮 Tic Tac Toe failed: ${error?.message || String(error)}`, m)
      }
   }
}

// Handles a player's plain numeric reply in the same group room.
export const event = {
   always: true,
   async: async (m, { client, body }) => {
      const game = games.get(keyOf(m))
      if (!game || game.state !== 'playing') return
      const position = Number(String(body || '').trim()) - 1
      if (!Number.isInteger(position) || position < 0 || position > 8) return
      const current = game.turn === 'X' ? game.x : game.o
      if (m.sender !== current) return
      if (game.board[position]) return client.reply(m.chat, '🎮 Kotak itu sudah dipilih.', m)

      game.board[position] = game.turn
      if (hasWon(game.board, game.turn)) {
         clearTimer(game)
         const winner = current
         await client.reply(m.chat, `🏆 ${tag(winner)} menang!\n\n${boardText(game.board)}`, m, { mentions: [winner] })
         games.delete(game.chat)
         return
      }
      if (game.board.every(Boolean)) {
         clearTimer(game)
         await client.reply(m.chat, `🤝 Permainan seri!\n\n${boardText(game.board)}`, m, { mentions: [game.x, game.o] })
         games.delete(game.chat)
         return
      }
      game.turn = game.turn === 'X' ? 'O' : 'X'
      await showBoard(client, game, m)
   }
}
