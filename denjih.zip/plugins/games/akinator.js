// Akinator game in one plugin file. Uses Node's built-in fetch only; no npm
// Akinator module or separate helper file is required.
const sessions = global.akinatorSessions ||= new Map()
const answers = ['Yes', 'No', "Don't know", 'Probably', 'Probably not']
const AKINATOR_BASE = 'https://id.akinator.com'
const browserHeaders = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36',
   Accept: 'application/json, text/plain, */*',
   'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
   Origin: AKINATOR_BASE,
   Referer: `${AKINATOR_BASE}/`
}
const keyOf = m => `${m.chat}:${m.sender}`
const cleanHtml = text => String(text || '')
   .replace(/<[^>]+>/g, '')
   .replace(/&quot;/g, '"').replace(/&#039;/g, "'")
   .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim()

async function request(path, data) {
   const response = await fetch(`${AKINATOR_BASE}/${path}`, {
      method: 'POST',
      headers: { ...browserHeaders, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(data),
      redirect: 'follow'
   })
   if (!response.ok) throw new Error(`Akinator HTTP ${response.status}`)
   const raw = await response.text()
   try { return JSON.parse(raw) } catch { return raw }
}
function render(session) {
   const progress = Number(session.progress || 0).toFixed(1)
   return `🎩 *AKINATOR*\n\n*Question ${Number(session.step) + 1}*\n${session.question}\n\n${answers.map((answer, index) => `${index + 1}. ${answer}`).join('\n')}\n\nProgress: ${progress}%\n\nReply *1-5* to answer.\nReply *back* to go back or *stop* to end.`
}
// Each question is sent as a new message. No WhatsApp edit-message payload is used.
async function sendQuestion(client, m, session, text) {
   await client.sendMessage(m.chat, { text }, { quoted: m })
}

export const run = {
   usage: ['akinator', 'aki'],
   use: 'start / stop',
   category: 'games',
   async: async (m, { client, text, Utils }) => {
      const id = keyOf(m)
      try {
         if (/^(stop|end|keluar)$/i.test(text)) {
            sessions.delete(id)
            return client.reply(m.chat, '🎩 Akinator session ended.', m)
         }
         if (sessions.has(id)) return client.reply(m.chat, '🎩 You already have an Akinator session. Reply 1-5, back, or stop.', m)

         await client.sendReact(m.chat, '🕒', m.key)
         const html = await request('game', { sid: '1', cm: 'true' })
         if (typeof html !== 'string') throw new Error('Akinator returned an invalid start response.')
         const session = html.match(/session:\s*'([^']+)'/)?.[1]
         const signature = html.match(/signature:\s*'([^']+)'/)?.[1]
         const question = cleanHtml(html.match(/question-text[^>]*>([\s\S]*?)<\/p>/)?.[1])
         if (!session || !signature || !question) throw new Error('Unable to start Akinator session.')

         const game = { session, signature, step: 0, progress: 0, question }
         sessions.set(id, game)
         await sendQuestion(client, m, game, render(game))
      } catch (error) {
         console.error(`[AKINATOR START ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🎩 Akinator failed: ${error?.message || String(error)}`, m)
      }
   },
   error: false
}

// Handles numeric replies in the same plugin file.
export const event = {
   // Run through the handler's always-event hook so numeric replies are never
   // skipped by ordinary message/event filters.
   always: true,
   async: async (m, { client, body }) => {
      const id = keyOf(m)
      const game = sessions.get(id)
      // Do not exclude fromMe: self-bot users answer from the same WhatsApp
      // account, so their numeric replies must still advance the game.
      if (!game) return
      const input = String(body || '').trim().toLowerCase()
      console.log(`[AKINATOR INPUT] user=${m.sender} chat=${m.chat} answer=${JSON.stringify(input)}`)
      try {
         if (/^(stop|end|keluar)$/i.test(input)) {
            sessions.delete(id)
            return client.reply(m.chat, '🎩 Akinator session ended.', m)
         }
         if (/^(back|kembali)$/i.test(input)) {
            const result = await request('cancel_answer', {
               step: game.step, progression: game.progress, sid: '1', cm: 'true', session: game.session, signature: game.signature
            })
            game.step = Number(result.step || 0)
            game.progress = Number(result.progression || 0)
            game.question = result.question || game.question
            return sendQuestion(client, m, game, render(game))
         }
         const selected = Number(input) - 1
         if (!Number.isInteger(selected) || selected < 0 || selected > 4) return

         const result = await request('answer', {
            step: game.step, progression: game.progress, sid: '1', cm: 'true', answer: selected,
            step_last_proposition: '', session: game.session, signature: game.signature
         })
         if (result.id_base_proposition || result.name_proposition) {
            sessions.delete(id)
            const name = result.name_proposition || result.proposition?.name || 'a character'
            return client.reply(m.chat, `🎩 I think it is *${name}*!\n\nWas I right?`, m)
         }
         game.step = Number(result.step || game.step + 1)
         game.progress = Number(result.progression || 0)
         game.question = result.question || game.question
         await sendQuestion(client, m, game, render(game))
      } catch (error) {
         console.error(`[AKINATOR EVENT ERROR] ${error?.stack || error}`)
         sessions.delete(id)
         await client.reply(m.chat, `🎩 Akinator session failed: ${error?.message || String(error)}`, m)
      }
   }
}
