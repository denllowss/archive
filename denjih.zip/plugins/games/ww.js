const games = global.werewolfGames ||= new Map()
const playerGames = global.werewolfPlayerGames ||= new Map()
const skillPolls = global.werewolfSkillPolls ||= new Map()

const roles = {
   wolf: {
      name: '🐺 Werewolf',
      skill: 'Pilih warga untuk dimangsa.'
   },
   seer: {
      name: '🔮 Seer',
      skill: 'Periksa role satu pemain.'
   },
   doctor: {
      name: '💊 Doctor',
      skill: 'Lindungi satu pemain.'
   },
   guard: {
      name: '🛡️ Guard',
      skill: 'Jaga pemain, tidak boleh target sama dua malam.'
   },
   witch: {
      name: '🧪 Witch',
      skill: 'Gunakan racun satu kali.'
   },
   hunter: {
      name: '🏹 Hunter',
      skill: 'Role Hunter diumumkan saat mati.'
   },
   cupid: {
      name: '💘 Cupid',
      skill: 'Pilih dua kekasih pada malam pertama.'
   },
   villager: {
      name: '👨‍🌾 Villager',
      skill: 'Cari Werewolf saat siang.'
   }
}

const tag = jid => `@${String(jid).replace(/@.+/, '')}`
const alive = game => game.players.filter(jid => game.alive.has(jid))
const roleOf = (game, jid) => game.roles.get(jid)

function clearTimer(game) {
   if (game.timer) clearTimeout(game.timer)
   game.timer = null
}

function randomize(array) {
   return [...array].sort(() => Math.random() - 0.5)
}

function winner(game) {
   const living = alive(game)
   const wolves = living.filter(jid => roleOf(game, jid) === 'wolf')

   if (!wolves.length) return 'citizen'
   if (wolves.length >= living.length - wolves.length) return 'wolf'

   return null
}

async function announce(client, game, text, mentions = []) {
   await client.reply(game.chat, text, null, { mentions })
}

async function endGame(client, game, side) {
   clearTimer(game)

   const result = game.players
      .map(jid => `${tag(jid)} — ${roles[roleOf(game, jid)].name}`)
      .join('\n')

   await announce(
      client,
      game,
      `🏆 *WEREWOLF SELESAI*

${side === 'wolf' ? '🐺 Werewolf menang!' : '👨‍🌾 Warga menang!'}

*Role seluruh pemain:*
${result}`,
      game.players
   )

   games.delete(game.chat)
   game.players.forEach(jid => playerGames.delete(jid))
}

async function checkWinner(client, game) {
   const side = winner(game)

   if (!side) return false

   await endGame(client, game, side)

   return true
}

function targetList(game, player, allowSelf = false) {
   return alive(game).filter(jid => allowSelf || jid !== player)
}

async function sendSkillPoll(client, game, player, role, targets) {
   const options = targets.map((jid, index) => {
      return `${index + 1}. ${tag(jid)}`
   })

   if (role === 'witch') {
      options.unshift('0. Tidak menggunakan racun')
   }

   const sent = await client.sendMessage(player, {
      poll: {
         name: `${roles[role].name}\n${roles[role].skill}`,
         values: options,
         selectableCount: role === 'cupid' ? 2 : 1
      }
   })

   skillPolls.set(sent.key.id, {
      game,
      player,
      role,
      targets,
      message: sent.message
   })
}

async function startNight(client, game) {
   game.phase = 'night'
   game.choices = new Map()

   await announce(
      client,
      game,
      `🌙 *MALAM ${game.round}*
Pemain dengan role skill akan menerima poll di private chat.`
   )

   for (const player of alive(game)) {
      const role = roleOf(game, player)

      if (!['wolf', 'seer', 'doctor', 'guard', 'witch', 'cupid'].includes(role)) {
         continue
      }

      if (role === 'cupid' && game.round > 1) {
         continue
      }

      const targets = role === 'wolf'
         ? alive(game).filter(jid => roleOf(game, jid) !== 'wolf')
         : targetList(game, player, role === 'doctor')

      await sendSkillPoll(client, game, player, role, targets)
   }

   clearTimer(game)

   game.timer = setTimeout(() => {
      resolveNight(client, game).catch(console.error)
   }, 90000)
}

async function resolveNight(client, game) {
   if (games.get(game.chat) !== game || game.phase !== 'night') return

   clearTimer(game)

   const living = alive(game)

   const wolves = living.filter(jid => roleOf(game, jid) === 'wolf')

   const wolfVotes = wolves
      .map(jid => game.choices.get(jid))
      .filter(Boolean)

   const count = new Map()

   wolfVotes.forEach(target => {
      count.set(target, (count.get(target) || 0) + 1)
   })

   const victim = [...count.entries()]
      .sort((a, b) => b[1] - a[1])[0]?.[0]

   const doctor = living.find(jid => roleOf(game, jid) === 'doctor')
   const guard = living.find(jid => roleOf(game, jid) === 'guard')
   const seer = living.find(jid => roleOf(game, jid) === 'seer')
   const witch = living.find(jid => roleOf(game, jid) === 'witch')

   const protectedPlayer = doctor
      ? game.choices.get(doctor)
      : null

   const guardedPlayer = guard
      ? game.choices.get(guard)
      : null

   if (guardedPlayer) game.guardLast = guardedPlayer

   if (seer && game.choices.get(seer)) {
      const target = game.choices.get(seer)

      await client.sendMessage(seer, {
         text: `🔮 Hasil ramalan:
${tag(target)} adalah *${roles[roleOf(game, target)].name}*.`,
         mentions: [target]
      })
   }

   if (
      victim &&
      victim !== protectedPlayer &&
      victim !== guardedPlayer
   ) {
      game.alive.delete(victim)

      await announce(
         client,
         game,
         `🌅 ${tag(victim)} ditemukan telah dimangsa Werewolf.`,
         [victim]
      )
   } else if (victim) {
      await announce(
         client,
         game,
         '🌅 Korban berhasil dilindungi.'
      )
   }

   const poisoned = witch && game.witchPoison
      ? game.choices.get(witch)?.poison
      : null

   if (poisoned && game.alive.has(poisoned)) {
      game.witchPoison = false
      game.alive.delete(poisoned)

      await announce(
         client,
         game,
         `🧪 ${tag(poisoned)} meninggal karena racun Witch.`,
         [poisoned]
      )
   }

   if (await checkWinner(client, game)) return

   await startDay(client, game)
}

async function startDay(client, game) {
   game.phase = 'day'
   game.votes = new Map()

   const options = alive(game).map((jid, index) => {
      return `${index + 1}. ${tag(jid)}`
   })

   const sent = await client.sendMessage(game.chat, {
      poll: {
         name: '☀️ VOTING WEREWOLF\nPilih pemain yang dicurigai.',
         values: options,
         selectableCount: 1
      }
   })

   game.dayPoll = {
      key: sent.key,
      message: sent.message,
      targets: alive(game)
   }

   clearTimer(game)

   game.timer = setTimeout(() => {
      resolveVote(client, game).catch(console.error)
   }, 120000)
}

async function resolveVote(client, game) {
   if (games.get(game.chat) !== game || game.phase !== 'day') return

   clearTimer(game)

   const counter = new Map()

   game.votes.forEach(target => {
      counter.set(target, (counter.get(target) || 0) + 1)
   })

   const selected = [...counter.entries()]
      .sort((a, b) => b[1] - a[1])[0]?.[0]

   if (selected) {
      game.alive.delete(selected)

      await announce(
         client,
         game,
         `🗳️ ${tag(selected)} dieliminasi.
Role: *${roles[roleOf(game, selected)].name}*.`,
         [selected]
      )
   } else {
      await announce(
         client,
         game,
         '🗳️ Tidak ada vote yang cukup.'
      )
   }

   if (await checkWinner(client, game)) return

   game.round++

   await startNight(client, game)
}

async function startGame(client, game) {
   const shuffled = randomize(game.players)

   const wolfCount = game.players.length >= 12
      ? 3
      : game.players.length >= 8
         ? 2
         : 1

   const deck = [
      ...Array(wolfCount).fill('wolf'),
      'seer',
      'doctor',
      ...(game.players.length >= 7 ? ['hunter'] : []),
      ...(game.players.length >= 8 ? ['witch'] : []),
      ...(game.players.length >= 10 ? ['guard'] : []),
      ...(game.players.length >= 12 ? ['cupid'] : [])
   ]

   while (deck.length < shuffled.length) {
      deck.push('villager')
   }

   shuffled.forEach((jid, index) => {
      game.roles.set(jid, deck[index])
   })

   game.alive = new Set(game.players)
   game.round = 1
   game.phase = 'night'
   game.guardLast = null
   game.witchPoison = true
   game.lovers = []

   for (const player of game.players) {
      const role = roleOf(game, player)

      await client.sendMessage(player, {
         text: `🎮 *WEREWOLF DIMULAI*

Role kamu: *${roles[role].name}*

${roles[role].skill}

Jangan bagikan role ke grup.`
      })
   }

   await startNight(client, game)
}

export const run = {
   usage: ['werewolf'],
   hidden: ['ww'],
   use: 'buat / join / mulai / batal',
   category: 'games',
   group: true,

   async: async (m, { client, args, Utils }) => {
      try {
         const option = String(args?.[0] || 'buat').toLowerCase()
         let game = games.get(m.chat)

         if (['buat', 'create'].includes(option)) {
            if (game) {
               return client.reply(
                  m.chat,
                  '🐺 Room Werewolf sudah ada.',
                  m
               )
            }

            game = {
               chat: m.chat,
               host: m.sender,
               players: [m.sender],
               roles: new Map(),
               alive: new Set(),
               phase: 'lobby',
               timer: null,
               round: 0
            }

            games.set(m.chat, game)
            playerGames.set(m.sender, game)

            return client.reply(
               m.chat,
               `🐺 *ROOM WEREWOLF DIBUAT*

Host: ${tag(m.sender)}

Pemain lain:
*.werewolf join*

Host mulai:
*.werewolf mulai*

Minimal 5 pemain.`,
               m,
               { mentions: [m.sender] }
            )
         }

         if (!game) {
            return client.reply(
               m.chat,
               '🐺 Belum ada room. Ketik *.werewolf buat*.',
               m
            )
         }

         if (option === 'join') {
            if (game.phase !== 'lobby') {
               return client.reply(m.chat, '🐺 Game sudah dimulai.', m)
            }

            if (game.players.includes(m.sender)) {
               return client.reply(m.chat, '🐺 Kamu sudah bergabung.', m)
            }

            game.players.push(m.sender)
            playerGames.set(m.sender, game)

            return client.reply(
               m.chat,
               `✅ ${tag(m.sender)} bergabung. Total: *${game.players.length} pemain*.`,
               m,
               { mentions: [m.sender] }
            )
         }

         if (['mulai', 'start'].includes(option)) {
            if (m.sender !== game.host) {
               return client.reply(
                  m.chat,
                  '🚩 Hanya host yang dapat memulai game.',
                  m
               )
            }

            if (game.players.length < 5) {
               return client.reply(
                  m.chat,
                  '🐺 Minimal 5 pemain untuk mulai.',
                  m
               )
            }

            if (game.phase !== 'lobby') {
               return client.reply(m.chat, '🐺 Game sudah berjalan.', m)
            }

            return startGame(client, game)
         }

         if (['batal', 'cancel', 'stop'].includes(option)) {
            if (m.sender !== game.host) {
               return client.reply(
                  m.chat,
                  '🚩 Hanya host yang dapat membatalkan game.',
                  m
               )
            }

            clearTimer(game)
            games.delete(m.chat)

            game.players.forEach(jid => {
               playerGames.delete(jid)
            })

            return client.reply(m.chat, '🐺 Game dibatalkan.', m)
         }

         return client.reply(
            m.chat,
            Utils.example('.', 'werewolf', 'buat'),
            m
         )
      } catch (error) {
         console.error('[WEREWOLF ERROR]', error)

         await client.reply(
            m.chat,
            `🐺 Werewolf failed: ${error.message || String(error)}`,
            m
         )
      }
   }
}

export const event = {
   always: true,

   async: async (m, { client, body }) => {
      if (m.isGroup) return

      const game = playerGames.get(m.sender)

      if (
         !game ||
         game.phase !== 'night' ||
         !game.alive.has(m.sender)
      ) {
         return
      }

      const match = String(body || '')
         .trim()
         .match(/^(?:ww|werewolf)\s+(.+)$/i)

      if (!match) return

      const role = roleOf(game, m.sender)

      if (!['wolf', 'seer', 'doctor', 'guard', 'witch', 'cupid'].includes(role)) {
         return client.reply(
            m.chat,
            '🐺 Role kamu tidak memiliki skill malam.',
            m
         )
      }

      const targets = role === 'wolf'
         ? alive(game).filter(jid => roleOf(game, jid) !== 'wolf')
         : targetList(game, m.sender, role === 'doctor')

      const values = match[1].trim().split(/\s+/)

      if (role === 'witch' && values[0] === '0') {
         game.choices.set(m.sender, {})
         return client.reply(m.chat, '✅ Witch tidak memakai racun.', m)
      }

      const poison = role === 'witch' &&
         values[0].toLowerCase() === 'poison'

      const numbers = (poison ? values.slice(1) : values)
         .map(Number)

      if (role === 'cupid' && numbers.length !== 2) {
         return client.reply(
            m.chat,
            '💘 Gunakan: *ww nomor1 nomor2*',
            m
         )
      }

      const selected = numbers
         .map(number => targets[number - 1])

      if (
         selected.some(value => !value) ||
         new Set(selected).size !== selected.length
      ) {
         return client.reply(m.chat, '🐺 Nomor tidak valid.', m)
      }

      if (role === 'guard' && selected[0] === game.guardLast) {
         return client.reply(
            m.chat,
            '🛡️ Guard tidak dapat menjaga target yang sama dua malam berturut-turut.',
            m
         )
      }

      if (role === 'cupid') {
         game.lovers = selected
         game.choices.set(m.sender, selected)

         await client.reply(
            m.chat,
            '💘 Pasangan kekasih berhasil dipilih.',
            m
         )
      } else if (role === 'witch') {
         game.choices.set(m.sender, {
            poison: selected[0]
         })

         await client.reply(
            m.chat,
            `✅ Racun dipilih untuk ${tag(selected[0])}.`,
            m,
            { mentions: selected }
         )
      } else {
         game.choices.set(m.sender, selected[0])

         await client.reply(
            m.chat,
            `✅ Target dipilih: ${tag(selected[0])}.`,
            m,
            { mentions: selected }
         )
      }

      const needed = alive(game).filter(jid => {
         const playerRole = roleOf(game, jid)

         return (
            ['wolf', 'seer', 'doctor', 'guard', 'witch']
               .includes(playerRole) ||
            (playerRole === 'cupid' && game.round === 1)
         )
      })

      if (needed.every(jid => game.choices.has(jid))) {
         await resolveNight(client, game)
      }
   }
}

export const onPollUpdate = async ({
   client,
   pollKey,
   pollUpdates,
   getAggregateVotesInPollMessage
}) => {
   for (const game of games.values()) {
      if (
         game.phase !== 'day' ||
         !game.dayPoll ||
         game.dayPoll.key.id !== pollKey.id
      ) {
         continue
      }

      const result = getAggregateVotesInPollMessage(
         {
            message: game.dayPoll.message,
            pollUpdates
         },
         client.user.id
      )

      for (const item of result) {
         const targetNumber = Number(
            item.name.match(/^(\d+)\./)?.[1]
         )

         const target = game.dayPoll.targets[targetNumber - 1]

         for (const voter of item.voters || []) {
            if (
               game.alive.has(voter) &&
               target &&
               voter !== target
            ) {
               game.votes.set(voter, target)
            }
         }
      }
   }
}