// One-file multiplayer "cepat ketik" room game. Words are fetched live from
// an API; no local/manual word list is used.
const rooms = global.quickTypingRooms ||= new Map()
const TOTAL_ROUNDS = 5
const ROUND_TIMEOUT = 15000
const keyOf = m => m.chat

async function fetchWord() {
   for (let attempt = 0; attempt < 3; attempt++) {
      const response = await fetch('https://random-word-api.herokuapp.com/word?number=1', {
         headers: { Accept: 'application/json', 'User-Agent': 'WhatsAppBot/1.0' }
      })
      if (!response.ok) continue
      const [word] = await response.json()
      if (typeof word === 'string' && /^[a-z]{3,20}$/i.test(word)) return word.toLowerCase()
   }
   throw new Error('Word API tidak memberikan kata yang valid.')
}
function clearTimer(room) {
   if (room.timer) clearTimeout(room.timer)
   room.timer = null
}
function playerName(jid) {
   return `@${String(jid).replace(/@.+/, '')}`
}
// Looks identical to the API word on WhatsApp, but copied text retains these
// invisible separators and will not equal the clean answer stored in room.word.
const displayWord = word => [...word].join('\u2060')
async function beginRound(client, room, replyTo) {
   clearTimer(room)
   if (room.round >= TOTAL_ROUNDS) return finishGame(client, room, replyTo)
   room.round++
   room.word = await fetchWord()
   room.startedAt = Date.now()
   const members = [...room.players]
   await client.reply(room.chat,
      `⌨️ *CEPAT KETIK — ROUND ${room.round}/${TOTAL_ROUNDS}*\n\nKetik kata ini secepat mungkin:\n\n*${displayWord(room.word)}*\n\nWaktu: *${ROUND_TIMEOUT / 1000} detik*`,
      replyTo,
      { mentions: members }
   )
   room.timer = setTimeout(async () => {
      try {
         if (rooms.get(room.chat) !== room || room.word === null) return
         room.word = null
         await client.reply(room.chat, `⏱️ Waktu habis! Kata yang benar: *${room.lastWord || '-'}*`, replyTo)
         await beginRound(client, room, replyTo)
      } catch (error) {
         console.error(`[CEPATKETIK TIMEOUT ERROR] ${error?.stack || error}`)
         rooms.delete(room.chat)
      }
   }, ROUND_TIMEOUT)
   room.lastWord = room.word
}
async function finishGame(client, room, replyTo) {
   clearTimer(room)
   const ranking = [...room.scores.entries()].sort((a, b) => b[1] - a[1])
   const result = ranking.length
      ? ranking.map(([jid, score], index) => `${index + 1}. ${playerName(jid)} — *${score} poin*`).join('\n')
      : 'Tidak ada poin yang didapat.'
   await client.reply(room.chat, `🏆 *CEPAT KETIK SELESAI*\n\n${result}`, replyTo, { mentions: ranking.map(([jid]) => jid) })
   rooms.delete(room.chat)
}

export const run = {
   usage: ['cepatketik'],
   hidden: ['cketik'],
   use: 'buat / join / mulai / batal',
   category: 'games',
   group: true,
   async: async (m, { client, args, Utils }) => {
      try {
         const roomId = keyOf(m)
         const option = String(args?.[0] || 'buat').toLowerCase()
         let room = rooms.get(roomId)

         if (['buat', 'create'].includes(option)) {
            if (room) return client.reply(m.chat, '⌨️ Room Cepat Ketik sudah ada. Gunakan *.cepatketik join*.', m)
            room = { chat: m.chat, owner: m.sender, players: new Set([m.sender]), scores: new Map([[m.sender, 0]]), round: 0, word: null, timer: null }
            rooms.set(roomId, room)
            return client.reply(m.chat, `⌨️ *ROOM CEPAT KETIK DIBUAT*\n\nHost: ${playerName(m.sender)}\n\nPemain lain ketik: *.cepatketik join*\nHost/admin ketik: *.cepatketik mulai*`, m, { mentions: [m.sender] })
         }
         if (!room) return client.reply(m.chat, '⌨️ Belum ada room. Ketik *.cepatketik buat*.', m)

         if (['join', 'masuk'].includes(option)) {
            if (room.word) return client.reply(m.chat, '⌨️ Game sudah berjalan. Tunggu room berikutnya.', m)
            if (room.players.has(m.sender)) return client.reply(m.chat, '⌨️ Kamu sudah bergabung di room ini.', m)
            room.players.add(m.sender)
            room.scores.set(m.sender, 0)
            return client.reply(m.chat, `✅ ${playerName(m.sender)} bergabung. Total pemain: *${room.players.size}*.`, m, { mentions: [m.sender] })
         }
         if (['mulai', 'start'].includes(option)) {
            if (m.sender !== room.owner) return client.reply(m.chat, '🚩 Hanya pembuat room yang dapat memulai permainan.', m)
            if (room.word) return client.reply(m.chat, '⌨️ Game sedang berjalan.', m)
            if (room.players.size < 2) return client.reply(m.chat, '⌨️ Minimal 2 pemain untuk memulai.', m)
            return beginRound(client, room, m)
         }
         if (['batal', 'cancel', 'stop'].includes(option)) {
            if (m.sender !== room.owner) return client.reply(m.chat, '🚩 Hanya pembuat room yang dapat membatalkan permainan.', m)
            clearTimer(room)
            rooms.delete(roomId)
            return client.reply(m.chat, '⌨️ Room Cepat Ketik dibatalkan.', m)
         }
         return client.reply(m.chat, Utils.example('.', 'cepatketik', 'buat'), m)
      } catch (error) {
         console.error(`[CEPATKETIK COMMAND ERROR] ${error?.stack || error}`)
         await client.reply(m.chat, `🚩 Cepat Ketik failed: ${error?.message || String(error)}`, m)
      }
   }
}

// One-file event hook: each player races by sending the fetched word.
export const event = {
   always: true,
   async: async (m, { client, body }) => {
      const room = rooms.get(keyOf(m))
      if (!room?.word || !room.players.has(m.sender)) return
      const answer = String(body || '').trim().toLowerCase()
      if (!answer || answer !== room.word) return
      const elapsed = ((Date.now() - room.startedAt) / 1000).toFixed(2)
      clearTimer(room)
      room.word = null
      room.scores.set(m.sender, (room.scores.get(m.sender) || 0) + 1)
      await client.reply(m.chat, `⚡ ${playerName(m.sender)} paling cepat!\nWaktu: *${elapsed} detik*\nPoin: *${room.scores.get(m.sender)}*`, m, { mentions: [m.sender] })
      await beginRound(client, room, m)
   }
}
